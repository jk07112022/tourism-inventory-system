<?php
require_once 'config.php';
requireLogin();

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as total_items FROM items");
$total_items = $stmt->fetch()['total_items'];

$stmt = $pdo->query("SELECT COUNT(*) as total_sales FROM sales WHERE DATE(sale_date) = CURDATE()");
$today_sales = $stmt->fetch()['total_sales'];

$stmt = $pdo->query("SELECT SUM(total_amount) as revenue FROM sales WHERE DATE(sale_date) = CURDATE()");
$today_revenue = $stmt->fetch()['revenue'] ?? 0;

$stmt = $pdo->query("SELECT COUNT(*) as low_stock FROM items WHERE quantity <= reorder_level");
$low_stock = $stmt->fetch()['low_stock'];

// Get top categories
$categories = $pdo->query("SELECT category, COUNT(*) as count FROM items GROUP BY category ORDER BY count DESC LIMIT 5")->fetchAll();

// Get recent sales count
$recent_sales_count = $pdo->query("SELECT COUNT(*) FROM sales WHERE DATE(sale_date) = CURDATE()")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Malaybalay City Tourism Inventory System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Dashboard specific styles */
        .welcome-banner {
            background: linear-gradient(135deg, #8B4513, #B22222);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 2rem;
            flex-wrap: wrap;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border: 3px solid #DAA520;
        }
        
        .welcome-logo {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50px;
            padding: 0.8rem 2rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            border: 2px solid #DAA520;
            backdrop-filter: blur(5px);
        }
        
        .welcome-logo img {
            height: 60px;
            width: auto;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));
        }
        
        .welcome-logo-text {
            display: flex;
            flex-direction: column;
        }
        
        .welcome-logo-text .city {
            font-weight: 800;
            font-size: 1.8rem;
            color: #FFD700; /* Bright gold */
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            letter-spacing: 2px;
        }
        
        .welcome-logo-text .tagline {
            font-size: 0.9rem;
            color: #FFFFFF;
            font-style: italic;
        }
        
        .welcome-text {
            flex: 1;
        }
        
        .welcome-text h2 {
            font-size: 2.2rem;
            margin-bottom: 0.5rem;
            color: #FFD700; /* Bright gold */
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        
        .welcome-text .greeting {
            font-size: 1.1rem;
            color: #FFFFFF;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .welcome-text .greeting span {
            background: rgba(255,255,255,0.2);
            padding: 0.3rem 1rem;
            border-radius: 25px;
            font-size: 0.9rem;
            border: 1px solid #DAA520;
        }
        
        .admin-badge {
            background: linear-gradient(135deg, #FFD700, #FFA500);
            color: #1e293b;
            padding: 0.2rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            margin-left: 0.5rem;
            border: 1px solid #FFFFFF;
        }
        
        .welcome-icon {
            font-size: 4rem;
            background: rgba(255, 255, 255, 0.2);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid #DAA520;
            color: #FFD700;
        }
        
        /* Dashboard Stats - FIXED VISIBILITY */
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 1.8rem 1.5rem;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 1.2rem;
            transition: all 0.3s ease;
            border: 2px solid #8B4513;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(139, 69, 19, 0.3);
        }
        
        .stat-card.warning {
            border-color: #B22222;
            background: white;
        }
        
        .stat-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #8B4513, #B22222);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            color: white;
            border: 3px solid #DAA520;
            flex-shrink: 0;
        }
        
        .stat-details {
            flex: 1;
        }
        
        .stat-details h3 {
            font-size: 0.9rem;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 0.3rem;
            font-weight: 600;
        }
        
        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: #1e293b !important; /* Dark color */
            line-height: 1.2;
        }
        
        .stat-card.warning .stat-number {
            color: #B22222 !important; /* Dark red for warning */
        }
        
        /* Quick Actions */
        .quick-actions {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border: 2px solid #8B4513;
        }
        
        .quick-actions h2 {
            color: #8B4513;
            border-bottom: 2px solid #DAA520;
            padding-bottom: 0.5rem;
            margin-bottom: 1.5rem;
            display: inline-block;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .action-card {
            flex: 1;
            min-width: 150px;
            background: #f8fafc;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            text-decoration: none;
            color: #1e293b;
            transition: all 0.3s ease;
            border: 2px solid #CD853F;
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            border-color: #DAA520;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            background: white;
        }
        
        .action-icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .action-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: #8B4513;
        }
        
        .action-desc {
            font-size: 0.8rem;
            color: #64748b;
        }
        
        /* Category Tags */
        .category-tag {
            display: inline-block;
            background: #8B4513;
            padding: 0.4rem 1.2rem;
            border-radius: 40px;
            font-size: 0.85rem;
            color: white;
            font-weight: 500;
            margin: 0.2rem;
            border: 1px solid #DAA520;
        }
        
        .category-badge {
            background: #8B4513;
            color: white;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        /* Tables */
        .table-responsive {
            background: white;
            border-radius: 20px;
            padding: 1rem;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            overflow-x: auto;
            border: 2px solid #8B4513;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th {
            text-align: left;
            padding: 1rem;
            background: #8B4513;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .table td {
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
            color: #1e293b;
        }
        
        .table tr:hover {
            background: #f8fafc;
        }
        
        .low-stock-row {
            background: #fff1f0;
            border-left: 4px solid #B22222;
        }
        
        .low-quantity {
            color: #B22222;
            font-weight: 700;
        }
        
        .price {
            font-weight: 700;
            color: #8B4513;
        }
        
        .badge {
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .badge-success {
            background: #2E7D32;
            color: white;
        }
        
        .badge-warning {
            background: #f8961e;
            color: white;
        }
        
        .badge-danger {
            background: #B22222;
            color: white;
        }
        
        .recent-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .recent-header h2 {
            color: #8B4513;
        }
        
        .view-all {
            color: #8B4513;
            text-decoration: none;
            font-weight: 500;
            padding: 0.3rem 1rem;
            border: 1px solid #8B4513;
            border-radius: 20px;
            transition: all 0.3s ease;
        }
        
        .view-all:hover {
            background: #8B4513;
            color: white;
        }
        
        /* Footer */
        .tourism-footer {
            text-align: center;
            margin-top: 3rem;
            padding: 2rem;
            background: #8B4513;
            border-radius: 30px 30px 0 0;
            color: white;
            border-top: 4px solid #DAA520;
        }
        
        .tourism-footer strong {
            color: #FFD700;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .welcome-banner {
                flex-direction: column;
                text-align: center;
            }
            
            .welcome-text h2 {
                font-size: 1.8rem;
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .stat-number {
                font-size: 2rem;
            }
        }
        
        /* Quantity indicator */
        .quantity {
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo-container">
            <img src="logo.png" alt="Malaybalay City Tourism" class="logo" onerror="this.src='logo.jpg'; this.onerror=null;">
            <div class="brand-text">
                <span class="brand-main">MALAYBALAY</span>
                <span class="brand-sub">coolplace • warmpeople</span>
            </div>
        </div>
        <div class="nav-menu">
            <a href="index.php" class="active">Dashboard</a>
            <a href="items.php">Items</a>
            <a href="sales.php">Sales</a>
            <a href="new_sale.php">New Sale</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        <div class="nav-user">
            Welcome, Mabuhay <?php echo $_SESSION['full_name'] ?? 'User'; ?>
        </div>
    </nav>

    <div class="container">
        <!-- Updated Welcome Banner - FIXED VISIBILITY -->
        <div class="welcome-banner">
            <div class="welcome-logo">
                <img src="logo.png" alt="Malaybalay City Tourism Logo" onerror="this.src='logo.jpg'; this.onerror=null;">
                <div class="welcome-logo-text">
                    <span class="city">MALAYBALAY</span>
                    <span class="tagline">coolplace • warmpeople</span>
                </div>
            </div>
            
            <div class="welcome-text">
                <h2>
                    Mabuhay! <?php echo $_SESSION['full_name'] ?? 'Guest'; ?> 👋
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                        <span class="admin-badge">Administrator</span>
                    <?php endif; ?>
                </h2>
                <div class="greeting">
                    <span> Welcome to Malaybalay City Tourism Inventory System</span>
                </div>
            </div>
            
            <div class="welcome-icon">
                🏞️
            </div>
        </div>
        
        <!-- Statistics Cards - FIXED VISIBILITY -->
        <div class="dashboard-stats">
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-details">
                    <h3>Total Items</h3>
                    <div class="stat-number"><?php echo $total_items; ?></div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-details">
                    <h3>Today's Revenue</h3>
                    <div class="stat-number"><?php echo formatPeso($today_revenue); ?></div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">🛒</div>
                <div class="stat-details">
                    <h3>Today's Sales</h3>
                    <div class="stat-number"><?php echo $today_sales; ?></div>
                </div>
            </div>
            
            <div class="stat-card warning">
                <div class="stat-icon">⚠️</div>
                <div class="stat-details">
                    <h3>Low Stock Items</h3>
                    <div class="stat-number"><?php echo $low_stock; ?></div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <h2>Quick Actions</h2>
            <div class="action-buttons">
                <a href="items.php" class="action-card">
                    <div class="action-icon">📦</div>
                    <div class="action-title">Manage Items</div>
                    <div class="action-desc">Add, edit or view items</div>
                </a>
                <a href="new_sale.php" class="action-card">
                    <div class="action-icon">💰</div>
                    <div class="action-title">New Sale</div>
                    <div class="action-desc">Record a customer purchase</div>
                </a>
                <a href="sales.php" class="action-card">
                    <div class="action-icon">📊</div>
                    <div class="action-title">View Sales</div>
                    <div class="action-desc">Check sales history</div>
                </a>
                <a href="reports.php" class="action-card">
                    <div class="action-icon">📈</div>
                    <div class="action-title">Reports</div>
                    <div class="action-desc">Analytics and insights</div>
                </a>
            </div>
        </div>

        <!-- Categories Overview -->
        <div class="quick-actions" style="margin-bottom: 2rem;">
            <h3>📁 Popular Categories</h3>
            <div style="margin-top: 1rem;">
                <?php foreach ($categories as $cat): ?>
                <span class="category-tag">
                    <?php echo htmlspecialchars($cat['category'] ?: 'Uncategorized'); ?> 
                    (<?php echo $cat['count']; ?>)
                </span>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Recent Items -->
        <div class="recent-items">
            <div class="recent-header">
                <h2>🆕 Recent Items</h2>
                <a href="items.php" class="view-all">View All →</a>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Category</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM items ORDER BY created_at DESC LIMIT 5");
                        while ($row = $stmt->fetch()):
                        ?>
                        <tr class="<?php echo $row['quantity'] <= $row['reorder_level'] ? 'low-stock-row' : ''; ?>">
                            <td>
                                <strong><?php echo htmlspecialchars($row['item_name']); ?></strong>
                                <?php if (!empty($row['description'])): ?>
                                <br><small style="color: #64748b;"><?php echo htmlspecialchars(substr($row['description'], 0, 50)) . '...'; ?></small>
                                <?php endif; ?>
                            </td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($row['category'] ?: 'Uncategorized'); ?></span></td>
                            <td>
                                <span class="quantity <?php echo $row['quantity'] <= $row['reorder_level'] ? 'low-quantity' : ''; ?>">
                                    <?php echo $row['quantity']; ?>
                                </span>
                            </td>
                            <td><span class="price"><?php echo formatPeso($row['price']); ?></span></td>
                            <td>
                                <?php if ($row['quantity'] <= 0): ?>
                                    <span class="badge badge-danger">Out of Stock</span>
                                <?php elseif ($row['quantity'] <= $row['reorder_level']): ?>
                                    <span class="badge badge-warning">Low Stock</span>
                                <?php else: ?>
                                    <span class="badge badge-success">In Stock</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Sales -->
        <div class="recent-items" style="margin-top: 2rem;">
            <div class="recent-header">
                <h2>🛍️ Recent Sales</h2>
                <a href="sales.php" class="view-all">View All →</a>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Invoice #</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Total</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $recent_sales = $pdo->query("
                            SELECT s.*, COUNT(si.id) as item_count 
                            FROM sales s 
                            LEFT JOIN sale_items si ON s.id = si.sale_id 
                            GROUP BY s.id 
                            ORDER BY s.sale_date DESC 
                            LIMIT 5
                        ");
                        while ($sale = $recent_sales->fetch()):
                        ?>
                        <tr>
                            <td><strong>#<?php echo htmlspecialchars($sale['invoice_number']); ?></strong></td>
                            <td>
                                <?php 
                                if (strpos($sale['customer_name'], 'Foreign Tourist') !== false) {
                                    echo '🌏 ' . htmlspecialchars($sale['customer_name']);
                                } else {
                                    echo '🇵🇭 ' . htmlspecialchars($sale['customer_name']);
                                }
                                ?>
                            </td>
                            <td><?php echo $sale['item_count']; ?> items</td>
                            <td class="price"><?php echo formatPeso($sale['total_amount']); ?></td>
                            <td><?php echo date('h:i A', strtotime($sale['sale_date'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Footer Note -->
        <div class="tourism-footer">
            <p>
                <strong>MALAYBALAY CITY TOURISM</strong> • coolplace • warmpeople • 
                <span style="color: #FFD700;">Inventory Management System</span>
            </p>
            <p style="font-size: 0.8rem; margin-top: 0.5rem;">
                🇵🇭 Discover the beauty of Malaybalay City, Bukidnon
            </p>
        </div>
    </div>
</body>
</html>