<?php
require_once 'config.php';
requireLogin();

// ============================================
// PART 1: HANDLE DELETE (Soft Delete)
// Place this code right after your require_once statements
// ============================================
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Soft delete - just mark as inactive instead of actually deleting
    try {
        $stmt = $pdo->prepare("UPDATE items SET status = 'inactive' WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: items.php?msg=deactivated');
        exit();
    } catch (PDOException $e) {
        header('Location: items.php?error=delete_failed');
        exit();
    }
}

// ============================================
// PART 2: HANDLE ADD/EDIT (Keep your existing code)
// ============================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'add') {
        try {
            // Add status='active' to your insert
            $stmt = $pdo->prepare("INSERT INTO items (item_code, item_name, category, description, quantity, price, supplier, reorder_level, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')");
            $stmt->execute([
                $_POST['item_code'],
                $_POST['item_name'],
                $_POST['category'],
                $_POST['description'],
                $_POST['quantity'],
                $_POST['price'],
                $_POST['supplier'],
                $_POST['reorder_level']
            ]);
            header('Location: items.php?msg=added');
            exit();
        } catch (PDOException $e) {
            $error = "Error adding item: " . $e->getMessage();
        }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'edit') {
        try {
            // Keep status as is when editing
            $stmt = $pdo->prepare("UPDATE items SET item_name=?, category=?, description=?, quantity=?, price=?, supplier=?, reorder_level=? WHERE id=?");
            $stmt->execute([
                $_POST['item_name'],
                $_POST['category'],
                $_POST['description'],
                $_POST['quantity'],
                $_POST['price'],
                $_POST['supplier'],
                $_POST['reorder_level'],
                $_POST['id']
            ]);
            header('Location: items.php?msg=updated');
            exit();
        } catch (PDOException $e) {
            $error = "Error updating item: " . $e->getMessage();
        }
    }
}

// ============================================
// PART 3: GET ITEMS - UPDATED QUERY
// Replace your existing $items query with this one
// ============================================
$items = $pdo->query("
    SELECT i.*, 
           (SELECT COUNT(*) FROM sale_items WHERE item_id = i.id) as sales_count 
    FROM items i 
    WHERE status = 'active'  // This line is important - only shows active items
    ORDER BY i.id DESC
")->fetchAll();

// ============================================
// PART 4: OPTIONAL - Get inactive items count for notification
// Add this if you want to show how many inactive items exist
// ============================================
$inactive_count = $pdo->query("SELECT COUNT(*) FROM items WHERE status = 'inactive'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items Management - City Tourism Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">🏛️ City Tourism Inventory</div>
        <div class="nav-menu">
            <a href="index.php">Dashboard</a>
            <a href="items.php" class="active">Items</a>
            <a href="sales.php">Sales</a>
            <a href="new_sale.php">New Sale</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Inventory Items</h1>
            <div style="display: flex; gap: 1rem;">
                <!-- Optional: Show inactive items count -->
                <?php if ($inactive_count > 0): ?>
                <span class="badge badge-warning" style="align-self: center;">
                    🗑️ <?php echo $inactive_count; ?> inactive items
                </span>
                <?php endif; ?>
                <button class="btn btn-primary" onclick="openAddModal()">
                    <span class="btn-icon">➕</span> Add New Item
                </button>
            </div>
        </div>

        <!-- Update your alert messages to include 'deactivated' -->
        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <?php 
                if ($_GET['msg'] == 'added') echo "✅ Item added successfully!";
                if ($_GET['msg'] == 'updated') echo "✅ Item updated successfully!";
                if ($_GET['msg'] == 'deactivated') echo "✅ Item moved to inactive items!";
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <?php 
                if ($_GET['error'] == 'delete_failed') echo "❌ Failed to deactivate item!";
                ?>
            </div>
        <?php endif; ?>

        <!-- Search Bar -->
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="🔍 Search items by name, code, or category..." onkeyup="searchItems()">
            <button onclick="searchItems()">Search</button>
        </div>

        <div class="table-responsive">
            <table class="table" id="itemsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item Code</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Supplier</th>
                        <th>Status</th>
                        <th>Sales</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr class="<?php echo $item['quantity'] <= $item['reorder_level'] ? 'low-stock-row' : ''; ?>">
                        <td>#<?php echo $item['id']; ?></td>
                        <td><span class="item-code"><?php echo htmlspecialchars($item['item_code']); ?></span></td>
                        <td><strong><?php echo htmlspecialchars($item['item_name']); ?></strong></td>
                        <td><span class="category-badge"><?php echo htmlspecialchars($item['category'] ?: 'Uncategorized'); ?></span></td>
                        <td>
                            <span class="quantity <?php echo $item['quantity'] <= $item['reorder_level'] ? 'low-quantity' : ''; ?>">
                                <?php echo $item['quantity']; ?>
                            </span>
                        </td>
                        <td><span class="price"><?php echo formatPeso($item['price']); ?></span></td>
                        <td><?php echo htmlspecialchars($item['supplier'] ?: 'N/A'); ?></td>
                        <td>
                            <?php if ($item['quantity'] <= 0): ?>
                                <span class="badge badge-danger">Out of Stock</span>
                            <?php elseif ($item['quantity'] <= $item['reorder_level']): ?>
                                <span class="badge badge-warning">Low Stock</span>
                            <?php else: ?>
                                <span class="badge badge-success">In Stock</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="sales-count" data-tooltip="Number of times sold">
                                <?php echo $item['sales_count']; ?> sales
                            </span>
                        </td>
                        <td class="actions">
                            <button class="btn btn-sm btn-info" onclick="editItem(<?php echo htmlspecialchars(json_encode($item)); ?>)">
                                ✏️ Edit
                            </button>
                            
                            <!-- Updated delete button - now uses soft delete -->
                            <a href="?delete=<?php echo $item['id']; ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirmDeactivate('<?php echo htmlspecialchars($item['item_name']); ?>')">
                                🗑️ Deactivate
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if (empty($items)): ?>
            <div class="empty-state">
                <i>📦</i>
                <h3>No Active Items Found</h3>
                <p>Get started by adding your first inventory item.</p>
                <button class="btn btn-primary" onclick="openAddModal()">Add New Item</button>
            </div>
        <?php endif; ?>
    </div>

    <!-- Add Item Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Item</h2>
            <form method="POST" action="">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label for="item_code">Item Code</label>
                    <input type="text" id="item_code" name="item_code" required>
                </div>
                
                <div class="form-group">
                    <label for="item_name">Item Name</label>
                    <input type="text" id="item_name" name="item_name" required>
                </div>
                
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select Category</option>
                        <option value="Souvenirs">Souvenirs</option>
                        <option value="Tickets">Tickets</option>
                        <option value="Tour Packages">Tour Packages</option>
                        <option value="Food & Beverages">Food & Beverages</option>
                        <option value="Miscellaneous">Miscellaneous</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" id="quantity" name="quantity" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="price">Price ($)</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="supplier">Supplier</label>
                        <input type="text" id="supplier" name="supplier">
                    </div>
                    
                    <div class="form-group">
                        <label for="reorder_level">Reorder Level</label>
                        <input type="number" id="reorder_level" name="reorder_level" value="10" min="0">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Add Item</button>
            </form>
        </div>
    </div>

    <!-- Edit Item Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Item</h2>
            <form method="POST" action="">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-group">
                    <label for="edit_item_name">Item Name</label>
                    <input type="text" id="edit_item_name" name="item_name" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_category">Category</label>
                    <select id="edit_category" name="category" required>
                        <option value="Souvenirs">Souvenirs</option>
                        <option value="Tickets">Tickets</option>
                        <option value="Tour Packages">Tour Packages</option>
                        <option value="Food & Beverages">Food & Beverages</option>
                        <option value="Miscellaneous">Miscellaneous</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_description">Description</label>
                    <textarea id="edit_description" name="description" rows="3"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_quantity">Quantity</label>
                        <input type="number" id="edit_quantity" name="quantity" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_price">Price ($)</label>
                        <input type="number" id="edit_price" name="price" step="0.01" min="0" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_supplier">Supplier</label>
                        <input type="text" id="edit_supplier" name="supplier">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_reorder_level">Reorder Level</label>
                        <input type="number" id="edit_reorder_level" name="reorder_level" min="0">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Update Item</button>
            </form>
        </div>
    </div>

    <style>
        /* Additional cool styles for items page */
        .item-code {
            font-family: monospace;
            background: #f0f0f0;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-size: 0.9rem;
        }
        
        .category-badge {
            background: linear-gradient(135deg, #667eea20, #764ba220);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        .quantity {
            font-weight: 600;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
        }
        
        .low-quantity {
            color: var(--danger-color);
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        
        .price {
            font-weight: 600;
            color: var(--success-color);
        }
        
        .sales-count {
            font-size: 0.85rem;
            padding: 0.2rem 0.5rem;
            background: #f0f0f0;
            border-radius: 4px;
        }
        
        .low-stock-row {
            background: linear-gradient(135deg, #fff3cd20, #ffe69c20);
            border-left: 3px solid var(--warning-color);
        }
        
        .btn-icon {
            margin-right: 0.5rem;
        }
        
        .search-box {
            margin-bottom: 1.5rem;
            background: white;
            padding: 1rem;
            border-radius: 15px;
            box-shadow: var(--shadow-sm);
        }
        
        .search-box input {
            border: 2px solid #e0e0e0;
            transition: all 0.3s ease;
        }
        
        .search-box input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
        }
    </style>

    <script>
        // Updated confirmation message
        function confirmDeactivate(itemName) {
            return confirm(`Are you sure you want to deactivate "${itemName}"?\nThis item will be hidden from active inventory but sales records will be preserved.`);
        }
        
        function searchItems() {
            let input = document.getElementById('searchInput');
            let filter = input.value.toUpperCase();
            let table = document.getElementById('itemsTable');
            let tr = table.getElementsByTagName('tr');
            
            for (let i = 1; i < tr.length; i++) {
                let tdName = tr[i].getElementsByTagName('td')[2];
                let tdCode = tr[i].getElementsByTagName('td')[1];
                let tdCategory = tr[i].getElementsByTagName('td')[3];
                
                if (tdName || tdCode || tdCategory) {
                    let nameValue = tdName.textContent || tdName.innerText;
                    let codeValue = tdCode.textContent || tdCode.innerText;
                    let categoryValue = tdCategory.textContent || tdCategory.innerText;
                    
                    if (nameValue.toUpperCase().indexOf(filter) > -1 || 
                        codeValue.toUpperCase().indexOf(filter) > -1 ||
                        categoryValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = '';
                    } else {
                        tr[i].style.display = 'none';
                    }
                }
            }
        }
        
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }
        
        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }
        
        function editItem(item) {
            document.getElementById('edit_id').value = item.id;
            document.getElementById('edit_item_name').value = item.item_name;
            document.getElementById('edit_category').value = item.category;
            document.getElementById('edit_description').value = item.description;
            document.getElementById('edit_quantity').value = item.quantity;
            document.getElementById('edit_price').value = item.price;
            document.getElementById('edit_supplier').value = item.supplier;
            document.getElementById('edit_reorder_level').value = item.reorder_level;
            
            document.getElementById('editModal').style.display = 'block';
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        window.onclick = function(event) {
            if (event.target.className == 'modal') {
                event.target.style.display = 'none';
            }
        }
        
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }
        });
    </script>
</body>
</html>