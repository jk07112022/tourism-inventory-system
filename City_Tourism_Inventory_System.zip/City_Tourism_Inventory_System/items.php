<?php
require_once 'config.php';
requireLogin();

// Handle Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    try {
        $check_stmt = $pdo->prepare("SELECT COUNT(*) as sale_count FROM sale_items WHERE item_id = ?");
        $check_stmt->execute([$id]);
        $result = $check_stmt->fetch();
        
        if ($result['sale_count'] > 0) {
            header('Location: items.php?error=has_sales');
            exit();
        } else {
            $img_stmt = $pdo->prepare("SELECT image FROM items WHERE id = ?");
            $img_stmt->execute([$id]);
            $item = $img_stmt->fetch();
            if ($item['image'] && file_exists('uploads/' . $item['image'])) {
                unlink('uploads/' . $item['image']);
            }
            
            $stmt = $pdo->prepare("DELETE FROM items WHERE id = ?");
            $stmt->execute([$id]);
            header('Location: items.php?msg=deleted');
            exit();
        }
    } catch (PDOException $e) {
        header('Location: items.php?error=delete_failed');
        exit();
    }
}

// Handle Restock All
if (isset($_POST['restock_all'])) {
    try {
        $restock_amount = intval($_POST['restock_amount']);
        
        if ($restock_amount > 0) {
            $stmt = $pdo->prepare("UPDATE items SET quantity = ?");
            $stmt->execute([$restock_amount]);
            $count = $stmt->rowCount();
            header("Location: items.php?msg=restocked&count=$count&amount=$restock_amount");
            exit();
        } else {
            header('Location: items.php?error=invalid_restock');
            exit();
        }
    } catch (PDOException $e) {
        header('Location: items.php?error=restock_failed');
        exit();
    }
}

// Handle Restock Low Stock Only
if (isset($_POST['restock_low'])) {
    try {
        $restock_amount = intval($_POST['restock_amount']);
        
        if ($restock_amount > 0) {
            $stmt = $pdo->prepare("UPDATE items SET quantity = ? WHERE quantity <= reorder_level");
            $stmt->execute([$restock_amount]);
            $count = $stmt->rowCount();
            header("Location: items.php?msg=restocked_low&count=$count&amount=$restock_amount");
            exit();
        } else {
            header('Location: items.php?error=invalid_restock');
            exit();
        }
    } catch (PDOException $e) {
        header('Location: items.php?error=restock_failed');
        exit();
    }
}

// ===== RESET ALL DATA FUNCTION =====
if (isset($_POST['reset_all_data']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    try {
        // Disable foreign key checks first (no transaction needed for TRUNCATE)
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        
        // Clear all tables (TRUNCATE is faster and resets AUTO_INCREMENT automatically)
        $pdo->exec("TRUNCATE TABLE sale_items");
        $pdo->exec("TRUNCATE TABLE sales");
        $pdo->exec("TRUNCATE TABLE items");
        $pdo->exec("TRUNCATE TABLE categories");
        
        // Re-enable foreign key checks
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        
        // Re-insert default categories
        $stmt = $pdo->prepare("INSERT INTO categories (category_name) VALUES ('Agri'), ('Paula''s'), ('Hinimo'), ('Valdez Handicraft')");
        $stmt->execute();
        
        // Clear uploaded images folder
        $files = glob('uploads/*');
        foreach($files as $file) {
            if(is_file($file)) {
                unlink($file);
            }
        }
        
        header('Location: items.php?msg=all_data_reset');
        exit();
        
    } catch (Exception $e) {
        // Re-enable foreign key checks even if error occurs
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $error = "Error resetting data: " . $e->getMessage();
    }
}
// ===== END RESET FUNCTION =====

// Handle Add Category
if (isset($_POST['action']) && $_POST['action'] == 'add_category') {
    try {
        $stmt = $pdo->prepare("INSERT INTO categories (category_name, description) VALUES (?, ?)");
        $stmt->execute([
            $_POST['new_category_name'],
            $_POST['category_description'] ?? ''
        ]);
        header('Location: items.php?msg=category_added');
        exit();
    } catch (PDOException $e) {
        $error = "Category already exists!";
    }
}

// Handle Category Delete
if (isset($_GET['delete_category'])) {
    $id = $_GET['delete_category'];
    
    try {
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM items WHERE category_id = ?");
        $check_stmt->execute([$id]);
        $in_use = $check_stmt->fetchColumn();
        
        if ($in_use > 0) {
            header('Location: items.php?error=category_in_use');
            exit();
        } else {
            $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            header('Location: items.php?msg=category_deleted');
            exit();
        }
    } catch (PDOException $e) {
        header('Location: items.php?error=category_delete_failed');
        exit();
    }
}

// Handle Add Item with Image Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    try {
        $image_name = null;
        if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $filename = $_FILES['item_image']['name'];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if (in_array($ext, $allowed)) {
                $image_name = time() . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
                $destination = 'uploads/' . $image_name;
                move_uploaded_file($_FILES['item_image']['tmp_name'], $destination);
            }
        }
        
        $cat_stmt = $pdo->prepare("SELECT category_name FROM categories WHERE id = ?");
        $cat_stmt->execute([$_POST['category_id']]);
        $category = $cat_stmt->fetch();
        
        $stmt = $pdo->prepare("INSERT INTO items (item_name, category, category_id, description, quantity, price, reorder_level, image, default_quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_POST['item_name'],
            $category['category_name'],
            $_POST['category_id'],
            $_POST['description'],
            $_POST['quantity'],
            $_POST['price'],
            $_POST['reorder_level'],
            $image_name,
            $_POST['quantity']
        ]);
        header('Location: items.php?msg=added');
        exit();
    } catch (PDOException $e) {
        $error = "Error adding item: " . $e->getMessage();
    }
}

// Handle Edit Item with Image Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit') {
    try {
        $current_img = $pdo->prepare("SELECT image FROM items WHERE id = ?");
        $current_img->execute([$_POST['id']]);
        $current = $current_img->fetch();
        $image_name = $current['image'];
        
        if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $filename = $_FILES['item_image']['name'];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if (in_array($ext, $allowed)) {
                if ($image_name && file_exists('uploads/' . $image_name)) {
                    unlink('uploads/' . $image_name);
                }
                $image_name = time() . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
                $destination = 'uploads/' . $image_name;
                move_uploaded_file($_FILES['item_image']['tmp_name'], $destination);
            }
        }
        
        $cat_stmt = $pdo->prepare("SELECT category_name FROM categories WHERE id = ?");
        $cat_stmt->execute([$_POST['category_id']]);
        $category = $cat_stmt->fetch();
        
        $stmt = $pdo->prepare("UPDATE items SET item_name=?, category=?, category_id=?, description=?, quantity=?, price=?, reorder_level=?, image=? WHERE id=?");
        $stmt->execute([
            $_POST['item_name'],
            $category['category_name'],
            $_POST['category_id'],
            $_POST['description'],
            $_POST['quantity'],
            $_POST['price'],
            $_POST['reorder_level'],
            $image_name,
            $_POST['id']
        ]);
        header('Location: items.php?msg=updated');
        exit();
    } catch (PDOException $e) {
        $error = "Error updating item: " . $e->getMessage();
    }
}

// Get all categories
$categories = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();

// Get all items with sales count
$items = $pdo->query("
    SELECT i.*, 
           (SELECT COUNT(*) FROM sale_items WHERE item_id = i.id) as sales_count
    FROM items i
    ORDER BY i.id DESC
")->fetchAll();

$low_stock_count = $pdo->query("SELECT COUNT(*) FROM items WHERE quantity <= reorder_level")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items Management - Malaybalay City Tourism</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Previous styles remain the same */
        .restock-section, .reset-section {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .restock-section { border: 2px solid #2E7D32; background: linear-gradient(135deg, #2E7D3220, #1B5E2020); }
        .reset-section { border: 2px solid #B22222; background: linear-gradient(135deg, #B2222220, #8B000020); }
        
        .restock-header, .reset-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .restock-title, .reset-title {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .restock-title h3 { color: #2E7D32; margin: 0; }
        .reset-title h3 { color: #B22222; margin: 0; }
        
        .restock-form {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .restock-input {
            width: 100px;
            padding: 0.5rem;
            border: 2px solid #2E7D32;
            border-radius: 8px;
            text-align: center;
        }
        
        .btn-restock {
            background: #2E7D32;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .btn-restock-low {
            background: #f8961e;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .low-stock-badge {
            background: #f8961e;
            color: white;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-left: 1rem;
        }
        
        .category-management {
            background: white;
            padding: 1.5rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            border: 2px solid #8B4513;
        }
        
        .category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .category-list {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .category-tag {
            background: linear-gradient(135deg, #8B4513, #B22222);
            padding: 0.5rem 1rem;
            border-radius: 25px;
            color: white;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .delete-cat {
            color: #FFD700;
            text-decoration: none;
            font-weight: bold;
        }
        
        .add-category-form {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .product-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        .category-badge {
            background: linear-gradient(135deg, #8B4513, #B22222);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            color: white;
            font-size: 0.85rem;
        }
        
        .low-stock-row {
            background: #fff3cd;
        }
        
        .low-quantity {
            color: #B22222;
            font-weight: bold;
        }
        
        .search-box {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
            background: white;
            padding: 1rem;
            border-radius: 15px;
        }
        
        .search-box input {
            flex: 1;
            padding: 0.5rem;
            border: 2px solid #CD853F;
            border-radius: 8px;
        }
        
        .search-box button {
            padding: 0.5rem 1rem;
            background: #8B4513;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .price {
            font-weight: bold;
            color: #8B4513;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 2rem;
            width: 90%;
            max-width: 600px;
            border-radius: 15px;
            max-height: 85vh;
            overflow-y: auto;
        }
        
        .close {
            float: right;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.3rem;
            font-weight: bold;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 0.5rem;
            border: 2px solid #CD853F;
            border-radius: 8px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .btn-primary {
            background: #8B4513;
            color: white;
        }
        
        .btn-success {
            background: #2E7D32;
            color: white;
        }
        
        .btn-danger {
            background: #B22222;
            color: white;
        }
        
        .btn-info {
            background: #DAA520;
            color: #3E2723;
        }
        
        .btn-sm {
            padding: 0.3rem 0.6rem;
            font-size: 0.8rem;
        }
        
        .btn-block {
            width: 100%;
        }
        
        .badge {
            padding: 0.2rem 0.5rem;
            border-radius: 15px;
            font-size: 0.75rem;
        }
        
        .badge-success {
            background: #2E7D32;
            color: white;
        }
        
        .badge-warning {
            background: #f8961e;
            color: white;
        }
        
        .badge-danger {
            background: #B22222;
            color: white;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 15px;
            overflow: hidden;
        }
        
        .table th {
            background: #8B4513;
            color: white;
            padding: 0.8rem;
            text-align: left;
        }
        
        .table td {
            padding: 0.8rem;
            border-bottom: 1px solid #ddd;
            vertical-align: middle;
        }
        
        .alert {
            padding: 0.8rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .product-thumb {
            width: 60px;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo-container">
            <img src="logo.png" alt="Malaybalay City Tourism" class="logo" onerror="this.src='logo.jpg'; this.onerror=null;">
            <div class="brand-text">
                <span class="brand-main">MALAYBALAY</span>
                <span class="brand-sub">coolplace • warmpeople</span>
            </div>
        </div>
        <div class="nav-menu">
            <a href="index.php">Dashboard</a>
            <a href="items.php" class="active">Items</a>
            <a href="sales.php">Sales</a>
            <a href="new_sale.php">New Sale</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        <div class="nav-user">
            Welcome, Mabuhay <?php echo $_SESSION['full_name'] ?? 'User'; ?>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>📦 Inventory Items</h1>
            <button class="btn btn-primary" onclick="openAddModal()">➕ Add New Item</button>
        </div>

        <!-- RESTOCK SECTION -->
        <div class="restock-section">
            <div class="restock-header">
                <div class="restock-title">
                    <span style="font-size: 2rem;">🔄</span>
                    <div>
                        <h3>Restock Inventory</h3>
                        <p style="color: #64748b; margin: 0; font-size: 0.85rem;">Update stock levels for all items</p>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 2rem; flex-wrap: wrap; margin-top: 1rem;">
                <form method="POST" action="" class="restock-form" onsubmit="return confirm('⚠️ This will set ALL items to the specified quantity. Continue?')">
                    <input type="hidden" name="restock_all" value="1">
                    <label style="font-weight: 500;">Set all items to:</label>
                    <input type="number" name="restock_amount" class="restock-input" value="50" min="1" required>
                    <button type="submit" class="btn-restock">🔄 Restock ALL Items</button>
                </form>
                
                <form method="POST" action="" class="restock-form" onsubmit="return confirm('⚠️ This will restock ONLY low stock items. Continue?')">
                    <input type="hidden" name="restock_low" value="1">
                    <label style="font-weight: 500;">Restock low stock to:</label>
                    <input type="number" name="restock_amount" class="restock-input" value="50" min="1" required>
                    <button type="submit" class="btn-restock-low">⚠️ Restock Low Stock Only</button>
                </form>
            </div>
            
            <div style="margin-top: 0.8rem; font-size: 0.8rem; color: #64748b;">
                <?php if ($low_stock_count > 0): ?>
                    <span class="low-stock-badge">⚠️ <?php echo $low_stock_count; ?> item(s) currently low on stock</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- RESET ALL DATA SECTION -->
        <div class="reset-section">
            <div class="reset-header">
                <div class="reset-title">
                    <span style="font-size: 2rem;">⚠️</span>
                    <div>
                        <h3>Reset All Data</h3>
                        <p style="color: #64748b; margin: 0; font-size: 0.85rem;">This will delete ALL items, categories, sales records, and images</p>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 1rem;">
                <form method="POST" action="" onsubmit="return confirmReset()">
                    <input type="hidden" name="reset_all_data" value="1">
                    <button type="submit" class="btn" style="background: #B22222; color: white; border: none; padding: 0.8rem 1.5rem; border-radius: 8px; cursor: pointer; font-weight: bold;">
                        🗑️ RESET ALL DATA (Cannot be undone)
                    </button>
                </form>
                <p style="font-size: 0.75rem; color: #B22222; margin-top: 0.5rem;">⚠️ This action is permanent and cannot be undone!</p>
            </div>
        </div>

        <!-- CATEGORY SECTION -->
        <div class="category-management">
            <div class="category-header">
                <h3>📁 Categories</h3>
                <button class="btn btn-info" onclick="toggleCategoryForm()">+ New Category</button>
            </div>
            
            <div id="addCategoryForm" class="add-category-form" style="display: none;">
                <form method="POST" action="" style="display: flex; gap: 1rem; width: 100%; flex-wrap: wrap;">
                    <input type="hidden" name="action" value="add_category">
                    <input type="text" name="new_category_name" placeholder="Category Name" required class="form-control" style="flex: 2;">
                    <input type="text" name="category_description" placeholder="Description" class="form-control" style="flex: 3;">
                    <button type="submit" class="btn btn-success">Add</button>
                    <button type="button" class="btn btn-danger" onclick="toggleCategoryForm()">Cancel</button>
                </form>
            </div>
            
            <div class="category-list">
                <?php foreach ($categories as $cat): ?>
                <span class="category-tag">
                    <?php echo htmlspecialchars($cat['category_name']); ?>
                    <?php
                    $check = $pdo->prepare("SELECT COUNT(*) FROM items WHERE category_id = ?");
                    $check->execute([$cat['id']]);
                    $in_use = $check->fetchColumn();
                    ?>
                    <?php if ($in_use == 0): ?>
                        <a href="?delete_category=<?php echo $cat['id']; ?>" class="delete-cat" onclick="return confirm('Delete category?')">×</a>
                    <?php endif; ?>
                </span>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- MESSAGES -->
        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <?php 
                if ($_GET['msg'] == 'added') echo "✅ Item added successfully!";
                if ($_GET['msg'] == 'updated') echo "✅ Item updated successfully!";
                if ($_GET['msg'] == 'deleted') echo "✅ Item deleted successfully!";
                if ($_GET['msg'] == 'category_added') echo "✅ Category added!";
                if ($_GET['msg'] == 'category_deleted') echo "✅ Category deleted!";
                if ($_GET['msg'] == 'restocked') echo "✅ " . ($_GET['count'] ?? 0) . " items restocked to " . ($_GET['amount'] ?? 0) . " units!";
                if ($_GET['msg'] == 'restocked_low') echo "✅ " . ($_GET['count'] ?? 0) . " low stock items restocked!";
                if ($_GET['msg'] == 'all_data_reset') echo "✅ All data has been reset! Categories have been restored to defaults.";
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <?php 
                if ($_GET['error'] == 'has_sales') echo "❌ Cannot delete item with sales history!";
                if ($_GET['error'] == 'category_in_use') echo "❌ Cannot delete category in use!";
                if ($_GET['error'] == 'invalid_restock') echo "❌ Invalid restock amount!";
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-error">❌ <?php echo $error; ?></div>
        <?php endif; ?>

        <!-- SEARCH -->
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="🔍 Search items by name or category..." onkeyup="searchItems()">
            <button onclick="searchItems()">Search</button>
        </div>

        <!-- ITEMS TABLE -->
        <div class="table-responsive">
            <table class="table" id="itemsTable">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($items)): ?>
                        <?php foreach ($items as $item): ?>
                        <tr class="<?php echo $item['quantity'] <= $item['reorder_level'] ? 'low-stock-row' : ''; ?>">
                            <td>
                                <?php if (!empty($item['image']) && file_exists('uploads/' . $item['image'])): ?>
                                    <img src="uploads/<?php echo $item['image']; ?>" class="product-image" alt="<?php echo htmlspecialchars($item['item_name']); ?>">
                                <?php else: ?>
                                    <div class="product-image" style="background:#f0f0f0; display:flex; align-items:center; justify-content:center;">📷</div>
                                <?php endif; ?>
                            </td>
                            <td>#<?php echo $item['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($item['item_name']); ?></strong><?php if(!empty($item['description'])): ?><br><small><?php echo htmlspecialchars(substr($item['description'],0,40)); ?></small><?php endif; ?></td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($item['category'] ?: 'Uncategorized'); ?></span></td>
                            <td><span class="<?php echo $item['quantity'] <= $item['reorder_level'] ? 'low-quantity' : ''; ?>"><?php echo $item['quantity']; ?></span></td>
                            <td><span class="price"><?php echo formatPeso($item['price']); ?></span></td>
                            <td>
                                <?php if ($item['quantity'] <= 0): ?>
                                    <span class="badge badge-danger">Out of Stock</span>
                                <?php elseif ($item['quantity'] <= $item['reorder_level']): ?>
                                    <span class="badge badge-warning">Low Stock</span>
                                <?php else: ?>
                                    <span class="badge badge-success">In Stock</span>
                                <?php endif; ?>
                                <br><small><?php echo $item['sales_count']; ?> sales</small>
                            </td>
                            <td class="actions">
                                <button class="btn btn-sm btn-info" 
                                        data-id="<?php echo $item['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($item['item_name'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-category-id="<?php echo $item['category_id']; ?>"
                                        data-description="<?php echo htmlspecialchars($item['description'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-quantity="<?php echo $item['quantity']; ?>"
                                        data-price="<?php echo $item['price']; ?>"
                                        data-reorder="<?php echo $item['reorder_level']; ?>"
                                        data-image="<?php echo $item['image']; ?>"
                                        onclick="editItemFromData(this)">
                                    ✏️ Edit
                                </button>
                                
                                <?php if ($item['sales_count'] > 0): ?>
                                    <button class="btn btn-sm btn-danger" disabled style="opacity:0.5">🚫 Delete</button>
                                <?php else: ?>
                                    <a href="?delete=<?php echo $item['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete item?')">🗑️ Delete</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 2rem;">No items found. Click "Add New Item" to get started.<?php if (isset($_GET['msg']) && $_GET['msg'] == 'all_data_reset'): ?><br><small style="color: #2E7D32;">Default categories have been added. You can now add new items!</small><?php endif; ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ADD MODAL -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Item</h2>
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label>Item Name</label>
                    <input type="text" name="item_name" required>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="category_id" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['category_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" name="quantity" min="0" value="0" required>
                    </div>
                    <div class="form-group">
                        <label>Price (₱)</label>
                        <input type="number" name="price" step="0.01" min="0" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Reorder Level</label>
                    <input type="number" name="reorder_level" value="10" min="0">
                </div>
                <div class="form-group">
                    <label>Product Image</label>
                    <input type="file" name="item_image" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Add Item</button>
            </form>
        </div>
    </div>

    <!-- EDIT MODAL -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Item</h2>
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                <div class="form-group">
                    <label>Item Name</label>
                    <input type="text" name="item_name" id="edit_item_name" required>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="category_id" id="edit_category_id" required>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['category_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="edit_description" rows="3"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" name="quantity" id="edit_quantity" min="0" required>
                    </div>
                    <div class="form-group">
                        <label>Price (₱)</label>
                        <input type="number" name="price" id="edit_price" step="0.01" min="0" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Reorder Level</label>
                    <input type="number" name="reorder_level" id="edit_reorder_level" min="0">
                </div>
                <div class="form-group">
                    <label>Change Image (optional)</label>
                    <input type="file" name="item_image" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Update Item</button>
            </form>
        </div>
    </div>

    <script>
        function toggleCategoryForm() {
            const form = document.getElementById('addCategoryForm');
            form.style.display = form.style.display === 'none' || form.style.display === '' ? 'flex' : 'none';
        }
        
        function openAddModal() { document.getElementById('addModal').style.display = 'block'; }
        function closeAddModal() { document.getElementById('addModal').style.display = 'none'; }
        function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }
        
        function editItemFromData(button) {
            document.getElementById('edit_id').value = button.dataset.id;
            document.getElementById('edit_item_name').value = button.dataset.name;
            document.getElementById('edit_category_id').value = button.dataset.categoryId;
            document.getElementById('edit_description').value = button.dataset.description || '';
            document.getElementById('edit_quantity').value = button.dataset.quantity;
            document.getElementById('edit_price').value = button.dataset.price;
            document.getElementById('edit_reorder_level').value = button.dataset.reorder;
            document.getElementById('editModal').style.display = 'block';
        }
        
        function searchItems() {
            const filter = document.getElementById('searchInput').value.toUpperCase();
            const rows = document.getElementById('itemsTable').getElementsByTagName('tr');
            for (let i = 1; i < rows.length; i++) {
                const name = rows[i].getElementsByTagName('td')[2];
                const category = rows[i].getElementsByTagName('td')[3];
                let found = false;
                if (name && name.textContent.toUpperCase().indexOf(filter) > -1) found = true;
                if (category && category.textContent.toUpperCase().indexOf(filter) > -1) found = true;
                rows[i].style.display = found ? '' : 'none';
            }
        }
        
        function confirmReset() {
            let confirmText = prompt('⚠️ WARNING: This will delete ALL data!\n\nType "RESET" to confirm resetting all data:');
            if (confirmText === 'RESET') {
                return confirm('FINAL WARNING: All items, categories, sales records, and images will be permanently deleted!\n\nClick OK to proceed.');
            } else {
                alert('Reset cancelled. You need to type "RESET" to confirm.');
                return false;
            }
        }
        
        window.onclick = function(event) {
            if (event.target.classList && event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>