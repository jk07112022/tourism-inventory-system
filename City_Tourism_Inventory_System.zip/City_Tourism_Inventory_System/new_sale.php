<?php
require_once 'config.php';
requireLogin();

// Get all items with stock > 0
$items = $pdo->query("SELECT * FROM items WHERE quantity > 0 ORDER BY item_name")->fetchAll();

// Process sale
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['process_sale'])) {
    try {
        $pdo->beginTransaction();
        
        $invoice_number = generateInvoiceNumber();
        $customer_type = $_POST['customer_type'];
        $customer_name = ($customer_type == 'Foreign') ? 'Foreign Tourist (' . $_POST['foreign_country'] . ')' : 'Local Customer';
        
        $stmt = $pdo->prepare("INSERT INTO sales (invoice_number, customer_name, total_amount, payment_method) VALUES (?, ?, ?, 'Cash')");
        $stmt->execute([$invoice_number, $customer_name, $_POST['total_amount']]);
        $sale_id = $pdo->lastInsertId();
        
        $items_data = json_decode($_POST['items_data'], true);
        foreach ($items_data as $item) {
            $stmt = $pdo->prepare("INSERT INTO sale_items (sale_id, item_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$sale_id, $item['id'], $item['quantity'], $item['price'], $item['subtotal']]);
            
            $stmt = $pdo->prepare("UPDATE items SET quantity = quantity - ? WHERE id = ?");
            $stmt->execute([$item['quantity'], $item['id']]);
        }
        
        $pdo->commit();
        header("Location: invoice.php?id=" . $sale_id);
        exit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error processing sale: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Sale - Malaybalay City Tourism</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { background: #f5f5f5; font-family: 'Poppins', sans-serif; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 1rem; }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .page-header h1 { font-size: 1.5rem; color: #8B4513; }
        
        .malaybalay-badge {
            background: linear-gradient(135deg, #8B4513, #B22222);
            color: white;
            padding: 0.3rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .sale-layout {
            display: grid;
            grid-template-columns: 1fr 380px;
            gap: 1.5rem;
        }
        
        /* LEFT PANEL - Items */
        .items-panel {
            background: white;
            border-radius: 16px;
            border: 1px solid #e0e0e0;
            overflow: hidden;
        }
        
        .panel-header {
            padding: 1rem 1.25rem;
            background: #f8f9fa;
            border-bottom: 2px solid #8B4513;
        }
        
        .panel-header h2 { font-size: 1.1rem; color: #8B4513; margin: 0; }
        
        .search-bar { padding: 1rem 1.25rem; background: white; border-bottom: 1px solid #eee; }
        
        .search-wrapper { display: flex; gap: 0.5rem; }
        
        .search-wrapper input {
            flex: 1;
            padding: 0.6rem 1rem;
            border: 1px solid #ddd;
            border-radius: 30px;
            font-size: 0.85rem;
            outline: none;
        }
        
        .search-wrapper input:focus { border-color: #8B4513; }
        
        .search-wrapper button {
            background: #8B4513;
            color: white;
            border: none;
            border-radius: 30px;
            padding: 0 1rem;
            cursor: pointer;
        }
        
        .items-grid {
            padding: 1rem;
            max-height: 450px;
            overflow-y: auto;
        }
        
        .item-card {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.8rem;
            border: 1px solid #eee;
            border-radius: 12px;
            margin-bottom: 0.6rem;
            cursor: pointer;
            transition: all 0.2s;
            background: white;
        }
        
        .item-card:hover { border-color: #8B4513; background: #fef5e8; transform: translateX(3px); }
        
        .item-card.selected { border-color: #8B4513; background: #fef5e8; border-left: 4px solid #DAA520; }
        
        .item-img {
            width: 50px;
            height: 50px;
            background: #f0f0f0;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }
        
        .item-img img { width: 50px; height: 50px; object-fit: cover; border-radius: 10px; }
        
        .item-details { flex: 1; }
        
        .item-name { font-weight: 600; font-size: 0.9rem; color: #1e293b; }
        .item-category { font-size: 0.7rem; color: #64748b; }
        .item-price { font-weight: 700; color: #8B4513; font-size: 0.9rem; }
        .item-stock { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 20px; background: #e8f5e9; color: #2E7D32; }
        .item-stock.low { background: #fff3e0; color: #f8961e; }
        
        .add-to-cart {
            padding: 1rem;
            background: #f8f9fa;
            border-top: 1px solid #eee;
            display: flex;
            gap: 0.8rem;
            align-items: center;
        }
        
        .qty-input {
            width: 80px;
            padding: 0.6rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            text-align: center;
        }
        
        .btn-add-cart {
            flex: 1;
            background: #8B4513;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 0.6rem;
            font-weight: 600;
            cursor: pointer;
        }
        
        .search-info { font-size: 0.7rem; color: #64748b; padding: 0.5rem 1rem; text-align: right; }
        
        /* RIGHT PANEL - Cart */
        .cart-panel {
            background: white;
            border-radius: 16px;
            border: 1px solid #e0e0e0;
            overflow: hidden;
            height: fit-content;
        }
        
        .cart-header {
            padding: 1rem 1.25rem;
            background: #f8f9fa;
            border-bottom: 2px solid #2E7D32;
        }
        
        .cart-header h2 { font-size: 1.1rem; color: #2E7D32; margin: 0; }
        
        .cart-items { max-height: 350px; overflow-y: auto; }
        
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.8rem 1rem;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .cart-item-info { flex: 1; }
        .cart-item-name { font-weight: 500; font-size: 0.85rem; }
        .cart-item-category { font-size: 0.65rem; color: #64748b; }
        .cart-item-qty { font-size: 0.85rem; margin: 0 1rem; }
        .cart-item-price { font-weight: 600; color: #8B4513; font-size: 0.85rem; min-width: 70px; text-align: right; }
        
        .btn-remove {
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            color: #B22222;
            padding: 0.3rem 0.5rem;
            border-radius: 20px;
        }
        
        .cart-summary {
            padding: 1rem;
            background: #f8f9fa;
            border-top: 2px solid #eee;
        }
        
        .summary-row { display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-size: 0.85rem; }
        .summary-total { display: flex; justify-content: space-between; margin-top: 0.5rem; padding-top: 0.5rem; border-top: 1px solid #ddd; font-weight: 700; font-size: 1rem; color: #8B4513; }
        
        .customer-section { margin-top: 1rem; padding: 1rem; background: #f8f9fa; border-radius: 12px; }
        
        .customer-type { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
        
        .type-btn {
            flex: 1;
            padding: 0.6rem;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 30px;
            background: white;
            cursor: pointer;
            font-size: 0.85rem;
        }
        
        .type-btn.local.active { background: #2E7D32; color: white; border-color: #2E7D32; }
        .type-btn.foreign.active { background: #4B0082; color: white; border-color: #4B0082; }
        
        .local-badge {
            background: #2E7D32;
            color: white;
            padding: 0.6rem;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 1rem;
            font-size: 0.85rem;
        }
        
        .country-select {
            width: 100%;
            padding: 0.6rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .payment-badge {
            background: #00b09b;
            color: white;
            padding: 0.6rem;
            border-radius: 8px;
            text-align: center;
            margin: 1rem 0;
            font-weight: 500;
        }
        
        .btn-process {
            width: 100%;
            padding: 0.8rem;
            background: #2E7D32;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
        }
        
        .empty-cart { text-align: center; padding: 2rem; color: #64748b; font-size: 0.85rem; }
        
        .alert { padding: 0.8rem; border-radius: 8px; margin-bottom: 1rem; font-size: 0.85rem; }
        .alert-error { background: #fee2e2; color: #B22222; }
        
        @media (max-width: 900px) { .sale-layout { grid-template-columns: 1fr; } }
        @media (max-width: 480px) { .container { padding: 0.5rem; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo-container">
            <img src="logo.png" alt="Malaybalay City Tourism" class="logo" onerror="this.src='logo.jpg'; this.onerror=null;">
            <div class="brand-text">
                <span class="brand-main">MALAYBALAY</span>
                <span class="brand-sub">coolplace • warmpeople</span>
            </div>
        </div>
        <div class="nav-menu">
            <a href="index.php">Dashboard</a>
            <a href="items.php">Items</a>
            <a href="sales.php">Sales</a>
            <a href="new_sale.php" class="active">New Sale</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        <div class="nav-user">
            Welcome, <?php echo $_SESSION['full_name'] ?? 'User'; ?>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>🛒 New Sale</h1>
            <span class="malaybalay-badge">MALAYBALAY CITY TOURISM</span>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="sale-layout">
            <!-- LEFT PANEL: Select Items -->
            <div class="items-panel">
                <div class="panel-header">
                    <h2>📦 Select Product</h2>
                </div>
                
                <div class="search-bar">
                    <div class="search-wrapper">
                        <input type="text" id="searchInput" placeholder="Search by name or category..." onkeyup="filterItems()">
                        <button onclick="filterItems()">🔍</button>
                    </div>
                </div>
                
                <div class="items-grid" id="itemsGrid">
                    <?php if (empty($items)): ?>
                        <div class="empty-cart">No items available</div>
                    <?php else: ?>
                        <?php foreach ($items as $item): ?>
                        <div class="item-card" 
                             data-id="<?php echo $item['id']; ?>"
                             data-name="<?php echo htmlspecialchars($item['item_name'], ENT_QUOTES, 'UTF-8'); ?>"
                             data-price="<?php echo $item['price']; ?>"
                             data-stock="<?php echo $item['quantity']; ?>"
                             data-category="<?php echo htmlspecialchars($item['category'], ENT_QUOTES, 'UTF-8'); ?>"
                             onclick="selectItem(this)">
                            
                            <div class="item-img">
                                <?php if (!empty($item['image']) && file_exists('uploads/' . $item['image'])): ?>
                                    <img src="uploads/<?php echo $item['image']; ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>">
                                <?php else: ?>
                                    📷
                                <?php endif; ?>
                            </div>
                            <div class="item-details">
                                <div class="item-name"><?php echo htmlspecialchars($item['item_name']); ?></div>
                                <div class="item-category"><?php echo htmlspecialchars($item['category']); ?></div>
                            </div>
                            <div class="item-price"><?php echo formatPeso($item['price']); ?></div>
                            <div class="item-stock <?php echo $item['quantity'] <= 5 ? 'low' : ''; ?>">
                                Stock: <?php echo $item['quantity']; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <div id="searchInfo" class="search-info"></div>
                
                <div class="add-to-cart">
                    <input type="number" id="quantityInput" class="qty-input" value="1" min="1">
                    <button onclick="addToCart()" class="btn-add-cart">➕ Add to Cart</button>
                </div>
            </div>

            <!-- RIGHT PANEL: Shopping Cart -->
            <div class="cart-panel">
                <div class="cart-header">
                    <h2>🛍️ Shopping Cart</h2>
                </div>
                
                <div class="cart-items" id="cartItemsList">
                    <div class="empty-cart">No items in cart</div>
                </div>
                
                <div class="cart-summary">
                    <div class="summary-row"><span>Items:</span><span id="summaryItemCount">0</span></div>
                    <div class="summary-row"><span>Total Quantity:</span><span id="summaryTotalQty">0</span></div>
                    <div class="summary-total"><span>Total Amount:</span><span id="summaryTotalAmount">₱0.00</span></div>
                </div>
                
                <div class="customer-section">
                    <div class="customer-type">
                        <div class="type-btn local active" onclick="setCustomerType('local')" id="localBtn">🇵🇭 Local</div>
                        <div class="type-btn foreign" onclick="setCustomerType('foreign')" id="foreignBtn">🌏 Foreign</div>
                    </div>
                    
                    <div id="localDisplay" class="local-badge">🇵🇭 Local Customer</div>
                    
                    <div id="foreignDisplay" style="display: none;">
                        <select id="foreignCountry" class="country-select">
                            <option value="">-- Select Country --</option>
                            <option value="USA">🇺🇸 United States</option>
                            <option value="Japan">🇯🇵 Japan</option>
                            <option value="South Korea">🇰🇷 South Korea</option>
                            <option value="China">🇨🇳 China</option>
                            <option value="UK">🇬🇧 United Kingdom</option>
                            <option value="Australia">🇦🇺 Australia</option>
                            <option value="Germany">🇩🇪 Germany</option>
                            <option value="France">🇫🇷 France</option>
                            <option value="Singapore">🇸🇬 Singapore</option>
                            <option value="Other">🌐 Other Country</option>
                        </select>
                    </div>
                    
                    <div class="payment-badge">💵 Cash Payment Only</div>
                    
                    <form method="POST" id="saleForm">
                        <input type="hidden" name="customer_type" id="customerType" value="Local">
                        <input type="hidden" name="foreign_country" id="foreignCountryInput">
                        <input type="hidden" name="items_data" id="itemsData">
                        <input type="hidden" name="total_amount" id="totalAmountInput">
                        <input type="hidden" name="process_sale" value="1">
                        <button type="submit" class="btn-process" onclick="return validateSale()">💵 Process Sale</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        let cart = [];
        let selectedItemElement = null;
        
        function selectItem(element) {
            document.querySelectorAll('.item-card').forEach(card => card.classList.remove('selected'));
            element.classList.add('selected');
            selectedItemElement = element;
        }
        
        function filterItems() {
            const term = document.getElementById('searchInput').value.toLowerCase();
            const items = document.querySelectorAll('.item-card');
            let visible = 0;
            items.forEach(item => {
                const name = item.getAttribute('data-name').toLowerCase();
                const category = item.getAttribute('data-category').toLowerCase();
                if (term === '' || name.includes(term) || category.includes(term)) {
                    item.style.display = 'flex';
                    visible++;
                } else {
                    item.style.display = 'none';
                }
            });
            document.getElementById('searchInfo').innerHTML = term ? `🔍 ${visible} item(s) found` : `📦 ${visible} items available`;
        }
        
        function addToCart() {
            if (!selectedItemElement) { alert('Please select an item first'); return; }
            
            const qty = parseInt(document.getElementById('quantityInput').value);
            if (qty < 1) { alert('Quantity must be at least 1'); return; }
            
            const id = selectedItemElement.getAttribute('data-id');
            const name = selectedItemElement.getAttribute('data-name');
            const price = parseFloat(selectedItemElement.getAttribute('data-price'));
            const stock = parseInt(selectedItemElement.getAttribute('data-stock'));
            const category = selectedItemElement.getAttribute('data-category');
            
            if (qty > stock) { alert('Only ' + stock + ' units available'); return; }
            
            const existing = cart.find(item => item.id === id);
            if (existing) {
                if (existing.quantity + qty > stock) { alert('Total exceeds available stock'); return; }
                existing.quantity += qty;
                existing.subtotal = existing.quantity * existing.price;
            } else {
                cart.push({ id, name, category, price, quantity: qty, subtotal: price * qty });
            }
            
            updateCartDisplay();
            document.getElementById('quantityInput').value = 1;
        }
        
        function removeFromCart(index) {
            cart.splice(index, 1);
            updateCartDisplay();
        }
        
        function updateCartDisplay() {
            const container = document.getElementById('cartItemsList');
            let total = 0, totalQty = 0;
            
            if (cart.length === 0) {
                container.innerHTML = '<div class="empty-cart">No items in cart</div>';
            } else {
                container.innerHTML = '';
                cart.forEach((item, idx) => {
                    total += item.subtotal;
                    totalQty += item.quantity;
                    container.innerHTML += `
                        <div class="cart-item">
                            <div class="cart-item-info">
                                <div class="cart-item-name">${escapeHtml(item.name)}</div>
                                <div class="cart-item-category">${escapeHtml(item.category)}</div>
                            </div>
                            <div class="cart-item-qty">x${item.quantity}</div>
                            <div class="cart-item-price">₱${item.subtotal.toFixed(2)}</div>
                            <button class="btn-remove" onclick="removeFromCart(${idx})">✕</button>
                        </div>
                    `;
                });
            }
            
            document.getElementById('summaryItemCount').textContent = cart.length;
            document.getElementById('summaryTotalQty').textContent = totalQty;
            document.getElementById('summaryTotalAmount').textContent = '₱' + total.toFixed(2);
            document.getElementById('totalAmountInput').value = total;
            document.getElementById('itemsData').value = JSON.stringify(cart);
        }
        
        function escapeHtml(text) { if (!text) return ''; return text.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]; }); }
        
        function setCustomerType(type) {
            const localBtn = document.getElementById('localBtn'), foreignBtn = document.getElementById('foreignBtn');
            const localDisplay = document.getElementById('localDisplay'), foreignDisplay = document.getElementById('foreignDisplay');
            const customerType = document.getElementById('customerType');
            
            if (type === 'local') {
                localBtn.classList.add('active'); foreignBtn.classList.remove('active');
                localDisplay.style.display = 'block'; foreignDisplay.style.display = 'none';
                customerType.value = 'Local';
                document.getElementById('foreignCountry').required = false;
            } else {
                foreignBtn.classList.add('active'); localBtn.classList.remove('active');
                localDisplay.style.display = 'none'; foreignDisplay.style.display = 'block';
                customerType.value = 'Foreign';
                document.getElementById('foreignCountry').required = true;
            }
        }
        
        function validateSale() {
            if (cart.length === 0) { alert('Please add items to the cart'); return false; }
            if (document.getElementById('customerType').value === 'Foreign') {
                const country = document.getElementById('foreignCountry').value;
                if (!country) { alert('Please select a country'); return false; }
                document.getElementById('foreignCountryInput').value = country;
            }
            return confirm('Process this sale?');
        }
        
        // Initialize
        const firstItem = document.querySelector('.item-card');
        if (firstItem) selectItem(firstItem);
        setCustomerType('local');
        filterItems();
        
        document.getElementById('quantityInput').addEventListener('keypress', e => { if (e.key === 'Enter') addToCart(); });
        document.getElementById('searchInput').addEventListener('keypress', e => { if (e.key === 'Enter') filterItems(); });
    </script>
</body>
</html>