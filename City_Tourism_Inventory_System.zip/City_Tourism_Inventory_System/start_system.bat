@echo off
title Malaybalay City Tourism Inventory System
color 0A

echo ========================================
echo    MALAYBALAY CITY TOURISM INVENTORY
echo    Starting System...
echo ========================================
echo.

:: Kill any existing PHP server on port 8000
echo [1] Stopping existing server on port 8000...
for /f "tokens=5" %%a in ('netstat -aon ^| find ":8000" ^| find "LISTENING"') do taskkill /f /pid %%a 2>nul

:: Start PHP server
echo [2] Starting PHP Server on port 8000...
start /B php -S localhost:8000

:: Wait 2 seconds for server to start
timeout /t 2 /nobreak >nul

:: Open browser
echo [3] Opening browser...
start http://localhost:8000

echo.
echo ========================================
echo    SYSTEM IS READY!
echo    Access at: http://localhost:8000
echo    Press any key to close this window
echo ========================================
pause >nul