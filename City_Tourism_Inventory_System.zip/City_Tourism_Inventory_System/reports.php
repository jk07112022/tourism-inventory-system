<?php
require_once 'config.php';
requireLogin();

// Get date range from request or default to last 30 days
$date_range = isset($_GET['date_range']) ? $_GET['date_range'] : 'last_30_days';
$custom_start = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$custom_end = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Build date condition based on selected range
$date_condition = "";
switch($date_range) {
    case 'today':
        $date_condition = "DATE(sale_date) = CURDATE()";
        $range_text = "Today";
        break;
    case 'yesterday':
        $date_condition = "DATE(sale_date) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        $range_text = "Yesterday";
        break;
    case 'this_week':
        $date_condition = "YEARWEEK(sale_date, 1) = YEARWEEK(CURDATE(), 1)";
        $range_text = "This Week";
        break;
    case 'this_month':
        $date_condition = "MONTH(sale_date) = MONTH(CURDATE()) AND YEAR(sale_date) = YEAR(CURDATE())";
        $range_text = "This Month";
        break;
    case 'last_30_days':
        $date_condition = "sale_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $range_text = "Last 30 Days";
        break;
    case 'custom':
        $date_condition = "DATE(sale_date) BETWEEN '$custom_start' AND '$custom_end'";
        $range_text = date('M d, Y', strtotime($custom_start)) . " - " . date('M d, Y', strtotime($custom_end));
        break;
    default:
        $date_condition = "sale_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $range_text = "Last 30 Days";
}

// Get sales data for charts with date filter
$daily_sales = $pdo->query("
    SELECT DATE_FORMAT(sale_date, '%Y-%m-%d') as date,
           DATE_FORMAT(sale_date, '%b %d') as day,
           COUNT(*) as sale_count,
           SUM(total_amount) as revenue
    FROM sales 
    WHERE $date_condition
    GROUP BY DATE(sale_date)
    ORDER BY sale_date ASC
")->fetchAll();

// Get summary statistics for the selected period
$summary = $pdo->query("
    SELECT 
        COUNT(DISTINCT id) as total_sales,
        COUNT(DISTINCT customer_name) as unique_customers,
        SUM(total_amount) as total_revenue,
        AVG(total_amount) as avg_sale_value
    FROM sales 
    WHERE $date_condition
")->fetch();

// Get top selling items for the period
$top_items = $pdo->query("
    SELECT i.item_name, 
           i.category,
           SUM(si.quantity) as total_sold,
           SUM(si.subtotal) as total_revenue
    FROM sale_items si
    JOIN items i ON si.item_id = i.id
    JOIN sales s ON si.sale_id = s.id
    WHERE $date_condition
    GROUP BY si.item_id
    ORDER BY total_sold DESC
    LIMIT 5
")->fetchAll();

// Get category distribution
$categories = $pdo->query("
    SELECT category, COUNT(*) as item_count, SUM(quantity) as total_stock
    FROM items
    GROUP BY category
")->fetchAll();

// Get customer type breakdown (Local vs Foreign)
$customer_types = $pdo->query("
    SELECT 
        CASE 
            WHEN customer_name LIKE 'Foreign Tourist%' THEN 'Foreign'
            ELSE 'Local'
        END as customer_type,
        COUNT(*) as count,
        SUM(total_amount) as total
    FROM sales 
    WHERE $date_condition
    GROUP BY 
        CASE 
            WHEN customer_name LIKE 'Foreign Tourist%' THEN 'Foreign'
            ELSE 'Local'
        END
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Malaybalay City Tourism Inventory</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Date range picker styles */
        .date-range-picker {
            background: white;
            padding: 1.5rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-sm);
            border: 2px solid var(--tribal-primary);
        }
        
        .range-options {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        
        .range-btn {
            padding: 0.5rem 1rem;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            background: white;
            color: var(--dark-color);
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .range-btn:hover {
            border-color: var(--tribal-gold);
            background: var(--tribal-gold);
            color: white;
        }
        
        .range-btn.active {
            background: var(--tribal-primary);
            color: white;
            border-color: var(--tribal-gold);
        }
        
        .custom-date-range {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e0e0e0;
        }
        
        .date-input {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .date-input label {
            font-weight: 500;
            color: var(--gray-color);
        }
        
        .date-input input {
            padding: 0.5rem;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-family: inherit;
        }
        
        .apply-btn {
            background: var(--tribal-primary);
            color: white;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .apply-btn:hover {
            background: var(--tribal-gold);
            transform: translateY(-2px);
        }
        
        .range-summary {
            background: linear-gradient(135deg, #667eea10, #764ba210);
            padding: 1rem;
            border-radius: 10px;
            margin-top: 1rem;
            font-size: 0.95rem;
            border-left: 4px solid var(--tribal-gold);
        }
        
        .summary-badge {
            background: var(--tribal-primary);
            color: white;
            padding: 0.2rem 0.8rem;
            border-radius: 15px;
            font-size: 0.8rem;
            margin-left: 0.5rem;
        }
        
        .insight-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow-sm);
            border-left: 4px solid var(--tribal-primary);
        }
        
        .insight-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--tribal-primary);
            margin: 0.5rem 0;
        }
        
        .insight-label {
            color: var(--gray-color);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .chart-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 2px solid var(--tribal-primary);
        }
        
        .category-badge {
            background: var(--tribal-primary);
            color: white;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-box {
            background: white;
            padding: 1.2rem;
            border-radius: 10px;
            text-align: center;
            border: 1px solid var(--tribal-secondary);
        }
        
        .stat-box .number {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--tribal-primary);
        }
        
        .stat-box .label {
            color: var(--gray-color);
            font-size: 0.9rem;
        }
        
        .customer-type-card {
            background: linear-gradient(135deg, #667eea10, #764ba210);
            border-radius: 10px;
            padding: 1rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .customer-icon {
            font-size: 2rem;
            background: var(--tribal-primary);
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo-container">
            <img src="logo.png" alt="Malaybalay City Tourism" class="logo" onerror="this.src='logo.jpg'; this.onerror=null;">
            <div class="brand-text">
                <span class="brand-main">MALAYBALAY</span>
                <span class="brand-sub">coolplace • warmpeople</span>
            </div>
        </div>
        <div class="nav-menu">
            <a href="index.php">Dashboard</a>
            <a href="items.php">Items</a>
            <a href="sales.php">Sales</a>
            <a href="new_sale.php">New Sale</a>
            <a href="reports.php" class="active">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        <div class="nav-user">
            Welcome, Mabuhay <?php echo $_SESSION['full_name'] ?? 'User'; ?>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>📊 Analytics & Reports</h1>
            <div style="display: flex; gap: 1rem; align-items: center;">
                <span class="malaybalay-badge">MALAYBALAY CITY TOURISM</span>
                <button onclick="window.print()" class="btn btn-primary">📄 Export Report</button>
            </div>
        </div>

        <!-- Date Range Picker -->
        <div class="date-range-picker">
            <form method="GET" action="" id="reportForm">
                <div class="range-options">
                    <button type="submit" name="date_range" value="today" class="range-btn <?php echo $date_range == 'today' ? 'active' : ''; ?>">Today</button>
                    <button type="submit" name="date_range" value="yesterday" class="range-btn <?php echo $date_range == 'yesterday' ? 'active' : ''; ?>">Yesterday</button>
                    <button type="submit" name="date_range" value="this_week" class="range-btn <?php echo $date_range == 'this_week' ? 'active' : ''; ?>">This Week</button>
                    <button type="submit" name="date_range" value="this_month" class="range-btn <?php echo $date_range == 'this_month' ? 'active' : ''; ?>">This Month</button>
                    <button type="submit" name="date_range" value="last_30_days" class="range-btn <?php echo $date_range == 'last_30_days' ? 'active' : ''; ?>">Last 30 Days</button>
                    <button type="button" class="range-btn" onclick="toggleCustomRange()">Custom Range</button>
                </div>
                
                <div id="customRange" class="custom-date-range" style="display: <?php echo $date_range == 'custom' ? 'flex' : 'none'; ?>">
                    <div class="date-input">
                        <label>From:</label>
                        <input type="date" name="start_date" value="<?php echo $custom_start; ?>" max="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="date-input">
                        <label>To:</label>
                        <input type="date" name="end_date" value="<?php echo $custom_end; ?>" max="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <input type="hidden" name="date_range" value="custom">
                    <button type="submit" class="apply-btn">Apply Range</button>
                </div>
            </form>
            
            <div class="range-summary">
                <strong>📅 Selected Period:</strong> <?php echo $range_text; ?> 
                <span class="summary-badge"><?php echo count($daily_sales); ?> days</span>
            </div>
        </div>

        <!-- Welcome message -->
        <div class="quick-actions" style="background: linear-gradient(135deg, #667eea20, #764ba220); margin-bottom: 2rem;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="font-size: 2rem;">🏞️</div>
                <div>
                    <h3 style="margin: 0; color: var(--tribal-primary);">MALAYBALAY CITY TOURISM</h3>
                    <p style="margin: 0.5rem 0 0 0; color: var(--gray-color);">coolplace • warmpeople • beautiful memories</p>
                </div>
            </div>
        </div>

        <!-- Summary Insights -->
        <div class="stats-grid">
            <div class="stat-box">
                <div class="number"><?php echo formatPeso($summary['total_revenue'] ?? 0); ?></div>
                <div class="label">Total Revenue</div>
                <small>₱<?php echo number_format(($summary['total_revenue'] ?? 0) / max(1, count($daily_sales)), 2); ?> avg/day</small>
            </div>
            <div class="stat-box">
                <div class="number"><?php echo $summary['total_sales'] ?? 0; ?></div>
                <div class="label">Total Sales</div>
                <small><?php echo round(($summary['total_sales'] ?? 0) / max(1, count($daily_sales)), 1); ?> sales/day</small>
            </div>
            <div class="stat-box">
                <div class="number"><?php echo $summary['unique_customers'] ?? 0; ?></div>
                <div class="label">Unique Customers</div>
                <small>Total visitors</small>
            </div>
            <div class="stat-box">
                <div class="number"><?php echo formatPeso($summary['avg_sale_value'] ?? 0); ?></div>
                <div class="label">Avg Sale Value</div>
                <small>per transaction</small>
            </div>
        </div>

        <!-- Customer Type Breakdown -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 2rem;">
            <?php 
            $local_count = 0;
            $local_total = 0;
            $foreign_count = 0;
            $foreign_total = 0;
            
            foreach ($customer_types as $ct) {
                if ($ct['customer_type'] == 'Local') {
                    $local_count = $ct['count'];
                    $local_total = $ct['total'];
                } else {
                    $foreign_count = $ct['count'];
                    $foreign_total = $ct['total'];
                }
            }
            ?>
            <div class="customer-type-card">
                <div class="customer-icon">🇵🇭</div>
                <div style="flex: 1;">
                    <div style="font-weight: 600;">Local Customers</div>
                    <div style="display: flex; justify-content: space-between; margin-top: 0.5rem;">
                        <span><?php echo $local_count; ?> transactions</span>
                        <span class="price"><?php echo formatPeso($local_total); ?></span>
                    </div>
                </div>
            </div>
            <div class="customer-type-card">
                <div class="customer-icon">🌏</div>
                <div style="flex: 1;">
                    <div style="font-weight: 600;">Foreign Tourists</div>
                    <div style="display: flex; justify-content: space-between; margin-top: 0.5rem;">
                        <span><?php echo $foreign_count; ?> transactions</span>
                        <span class="price"><?php echo formatPeso($foreign_total); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Revenue Chart -->
        <div class="chart-container">
            <h2 style="color: var(--tribal-primary); margin-bottom: 1rem;">Daily Revenue - <?php echo $range_text; ?></h2>
            <?php if (empty($daily_sales)): ?>
                <div class="empty-state" style="padding: 3rem;">
                    <i>📊</i>
                    <h3>No Data Available</h3>
                    <p>No sales records found for the selected period.</p>
                </div>
            <?php else: ?>
                <canvas id="revenueChart" style="max-height: 400px;"></canvas>
            <?php endif; ?>
        </div>

        <!-- Top Selling Items and Category Distribution -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
            <!-- Top Selling Items -->
            <div class="quick-actions" style="margin-bottom: 0;">
                <h3 style="color: var(--tribal-primary); margin-bottom: 1rem;">🏆 Top Selling Items</h3>
                <?php if (empty($top_items)): ?>
                    <div class="empty-state" style="padding: 2rem;">
                        <p>No sales data available</p>
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Category</th>
                                <th>Qty</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_items as $item): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($item['item_name']); ?></strong></td>
                                <td><span class="category-badge"><?php echo htmlspecialchars($item['category'] ?: 'N/A'); ?></span></td>
                                <td><?php echo $item['total_sold']; ?></td>
                                <td class="price"><?php echo formatPeso($item['total_revenue']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Category Distribution -->
            <div class="quick-actions" style="margin-bottom: 0;">
                <h3 style="color: var(--tribal-primary); margin-bottom: 1rem;">📦 Inventory by Category</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Items</th>
                            <th>Stock</th>
                            <th>Distribution</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_stock = array_sum(array_column($categories, 'total_stock'));
                        foreach ($categories as $cat): 
                        $percentage = $total_stock > 0 ? round(($cat['total_stock'] / $total_stock) * 100) : 0;
                        ?>
                        <tr>
                            <td><span class="category-badge"><?php echo htmlspecialchars($cat['category'] ?: 'Uncategorized'); ?></span></td>
                            <td><?php echo $cat['item_count']; ?></td>
                            <td><?php echo $cat['total_stock']; ?></td>
                            <td style="width: 150px;">
                                <div class="progress-bar">
                                    <div class="progress-bar-fill" style="width: <?php echo $percentage; ?>%;"></div>
                                </div>
                                <small><?php echo $percentage; ?>%</small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Transactions -->
        <div class="quick-actions" style="margin-top: 1rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h3 style="color: var(--tribal-primary);">🛍️ Recent Transactions</h3>
                <a href="sales.php" class="btn btn-sm btn-primary">View All</a>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent = $pdo->prepare("SELECT * FROM sales WHERE $date_condition ORDER BY sale_date DESC LIMIT 10");
                    $recent->execute();
                    if ($recent->rowCount() > 0):
                        while ($row = $recent->fetch()):
                    ?>
                    <tr>
                        <td><strong>#<?php echo htmlspecialchars($row['invoice_number']); ?></strong></td>
                        <td><?php echo date('M d, h:i A', strtotime($row['sale_date'])); ?></td>
                        <td>
                            <?php 
                            if (strpos($row['customer_name'], 'Foreign Tourist') !== false) {
                                echo '🌏 ' . $row['customer_name'];
                            } else {
                                echo '🇵🇭 ' . $row['customer_name'];
                            }
                            ?>
                        </td>
                        <td>
                            <?php
                            $item_count = $pdo->prepare("SELECT COUNT(*) FROM sale_items WHERE sale_id = ?");
                            $item_count->execute([$row['id']]);
                            echo $item_count->fetchColumn() . ' items';
                            ?>
                        </td>
                        <td class="price"><?php echo formatPeso($row['total_amount']); ?></td>
                    </tr>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 2rem;">
                            No transactions found for this period
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Footer -->
        <div class="tourism-footer">
            <p>
                <strong>MALAYBALAY CITY TOURISM</strong> • coolplace • warmpeople • 
                <span style="color: #FFD700;">Inventory Management System</span>
            </p>
            <p style="font-size: 0.8rem; margin-top: 0.5rem;">
                🇵🇭 Discover the beauty of Malaybalay City, Bukidnon
            </p>
            <p style="font-size: 0.7rem; color: rgba(255,255,255,0.7);">
                Report generated: <?php echo date('F d, Y h:i A'); ?>
            </p>
        </div>
    </div>

    <script>
        // Toggle custom date range
        function toggleCustomRange() {
            var customRange = document.getElementById('customRange');
            if (customRange.style.display === 'none' || customRange.style.display === '') {
                customRange.style.display = 'flex';
                // Set default dates if not set
                var today = new Date().toISOString().split('T')[0];
                var lastWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                document.querySelector('input[name="start_date"]').value = lastWeek;
                document.querySelector('input[name="end_date"]').value = today;
            } else {
                customRange.style.display = 'none';
            }
        }

        // Revenue Chart
        <?php if (!empty($daily_sales)): ?>
        const ctx = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($daily_sales, 'day')); ?>,
                datasets: [{
                    label: 'Daily Revenue (₱)',
                    data: <?php echo json_encode(array_column($daily_sales, 'revenue')); ?>,
                    borderColor: '#8B4513',
                    backgroundColor: 'rgba(139, 69, 19, 0.1)',
                    borderWidth: 3,
                    pointBackgroundColor: '#DAA520',
                    pointBorderColor: '#8B4513',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 8,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Number of Sales',
                    data: <?php echo json_encode(array_column($daily_sales, 'sale_count')); ?>,
                    borderColor: '#DAA520',
                    backgroundColor: 'rgba(218, 165, 32, 0.1)',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    pointRadius: 3,
                    yAxisID: 'y1',
                    tension: 0.4,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    tooltip: {
                        backgroundColor: '#3E2723',
                        titleColor: '#FFD700',
                        bodyColor: '#FFFFFF',
                        padding: 10,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label.includes('Revenue')) {
                                    return label + ': ₱' + context.raw.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
                                }
                                return label + ': ' + context.raw;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        position: 'left',
                        grid: {
                            color: 'rgba(0,0,0,0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString();
                            }
                        },
                        title: {
                            display: true,
                            text: 'Revenue (₱)'
                        }
                    },
                    y1: {
                        beginAtZero: true,
                        position: 'right',
                        grid: {
                            drawOnChartArea: false,
                        },
                        ticks: {
                            callback: function(value) {
                                return value + ' sales';
                            }
                        },
                        title: {
                            display: true,
                            text: 'Number of Sales'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>