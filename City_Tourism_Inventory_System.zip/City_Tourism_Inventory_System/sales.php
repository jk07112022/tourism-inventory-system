<?php
require_once 'config.php';
requireLogin();

// Get all sales with item count
$sales = $pdo->query("
    SELECT s.*, COUNT(si.id) as item_count 
    FROM sales s 
    LEFT JOIN sale_items si ON s.id = si.sale_id 
    GROUP BY s.id 
    ORDER BY s.sale_date DESC
")->fetchAll();

// Calculate summary statistics
$total_revenue = 0;
$total_transactions = count($sales);
$total_items_sold = 0;

foreach ($sales as $sale) {
    $total_revenue += $sale['total_amount'];
    $total_items_sold += $sale['item_count'];
}

$avg_sale = $total_transactions > 0 ? $total_revenue / $total_transactions : 0;

// Function to get payment method badge - CASH ONLY
function getPaymentMethodBadge($method) {
    // Always return Cash badge regardless of what's in database
    return '<span class="payment-badge payment-cash">💵 Cash</span>';
}

// Function to format customer name with flag
function formatCustomerName($customer_name) {
    if (strpos($customer_name, 'Foreign Tourist') !== false) {
        // Extract country from the string
        preg_match('/\((.*?)\)/', $customer_name, $matches);
        $country = isset($matches[1]) ? $matches[1] : 'Unknown';
        
        // Add flag emoji based on country
        $flag = '🌏';
        $country_lower = strtolower($country);
        
        $flag_map = [
            'usa' => '🇺🇸', 'united states' => '🇺🇸',
            'canada' => '🇨🇦',
            'uk' => '🇬🇧', 'united kingdom' => '🇬🇧',
            'australia' => '🇦🇺',
            'japan' => '🇯🇵',
            'south korea' => '🇰🇷', 'korea' => '🇰🇷',
            'china' => '🇨🇳',
            'singapore' => '🇸🇬',
            'malaysia' => '🇲🇾',
            'thailand' => '🇹🇭',
            'vietnam' => '🇻🇳',
            'india' => '🇮🇳',
            'germany' => '🇩🇪',
            'france' => '🇫🇷',
            'italy' => '🇮🇹',
            'spain' => '🇪🇸',
            'netherlands' => '🇳🇱',
            'switzerland' => '🇨🇭',
            'brazil' => '🇧🇷',
            'mexico' => '🇲🇽'
        ];
        
        foreach ($flag_map as $key => $flag_emoji) {
            if (strpos($country_lower, $key) !== false) {
                $flag = $flag_emoji;
                break;
            }
        }
        
        return $flag . ' ' . $customer_name;
    } elseif ($customer_name == 'Local Customer') {
        return '🇵🇭 Local Customer';
    } else {
        return $customer_name;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Records - Malaybalay City Tourism Inventory</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Page header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            background: white;
            padding: 1.5rem;
            border-radius: 15px;
            border: 2px solid var(--tribal-primary);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .page-header h1 {
            color: var(--tribal-primary);
            margin: 0;
            font-size: 2rem;
        }
        
        /* Summary Cards - FIXED VISIBILITY */
        .sales-summary {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .summary-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            border: 2px solid var(--tribal-secondary);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .summary-card .label {
            color: #64748b;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .summary-card .value {
            font-size: 2.2rem;
            font-weight: 800;
            color: #1e293b !important; /* Dark color */
            line-height: 1.2;
            margin-bottom: 0.3rem;
        }
        
        .summary-card .sub-value {
            color: #475569;
            font-size: 0.85rem;
        }
        
        /* Cash summary card - SIMPLIFIED */
        .cash-summary {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            border: 2px solid #00b09b;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }
        
        .cash-icon {
            font-size: 2.5rem;
            background: #00b09b;
            color: white;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .cash-details {
            flex: 1;
        }
        
        .cash-details .title {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 0.5rem;
            font-size: 1.2rem;
        }
        
        .cash-stats {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }
        
        .stat-item {
            display: flex;
            flex-direction: column;
        }
        
        .stat-item .stat-label {
            color: #64748b;
            font-size: 0.85rem;
            text-transform: uppercase;
        }
        
        .stat-item .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1e293b;
        }
        
        /* Table styles */
        .table-responsive {
            background: white;
            border-radius: 20px;
            padding: 1rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border: 2px solid var(--tribal-primary);
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th {
            text-align: left;
            padding: 1rem;
            background: var(--tribal-primary);
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .table td {
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
            color: #1e293b;
        }
        
        .table tr:hover {
            background: #f8fafc;
        }
        
        /* Payment badge - CASH ONLY */
        .payment-badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            white-space: nowrap;
        }
        
        .payment-cash {
            background: #00b09b;
            color: white;
        }
        
        /* Invoice number */
        .invoice-number {
            font-family: monospace;
            font-weight: 600;
            color: var(--tribal-primary);
        }
        
        /* Customer name */
        .customer-name {
            font-weight: 500;
        }
        
        /* Item count badge */
        .item-count {
            background: #f1f5f9;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            color: #475569;
        }
        
        /* Price styling */
        .price {
            font-weight: 700;
            color: var(--tribal-primary);
        }
        
        /* View button */
        .btn-view {
            background: var(--tribal-primary);
            color: white;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .btn-view:hover {
            background: var(--tribal-gold);
            transform: translateY(-2px);
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: var(--tribal-secondary);
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            color: #1e293b;
            margin-bottom: 0.5rem;
        }
        
        .empty-state p {
            color: #64748b;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sales-summary {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .cash-stats {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo-container">
            <img src="logo.png" alt="Malaybalay City Tourism" class="logo" onerror="this.src='logo.jpg'; this.onerror=null;">
            <div class="brand-text">
                <span class="brand-main">MALAYBALAY</span>
                <span class="brand-sub">coolplace • warmpeople</span>
            </div>
        </div>
        <div class="nav-menu">
            <a href="index.php">Dashboard</a>
            <a href="items.php">Items</a>
            <a href="sales.php" class="active">Sales</a>
            <a href="new_sale.php">New Sale</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        <div class="nav-user">
            Welcome, Mabuhay <?php echo $_SESSION['full_name'] ?? 'User'; ?>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>📊 Sales Records</h1>
            <a href="new_sale.php" class="btn btn-success">
                <span class="btn-icon">➕</span> New Sale
            </a>
        </div>

        <!-- Sales Summary Cards -->
        <?php if (!empty($sales)): ?>
        <div class="sales-summary">
            <div class="summary-card">
                <div class="label">Total Revenue</div>
                <div class="value"><?php echo formatPeso($total_revenue); ?></div>
                <div class="sub-value">All time sales</div>
            </div>
            <div class="summary-card">
                <div class="label">Transactions</div>
                <div class="value"><?php echo number_format($total_transactions); ?></div>
                <div class="sub-value">Total sales count</div>
            </div>
            <div class="summary-card">
                <div class="label">Items Sold</div>
                <div class="value"><?php echo number_format($total_items_sold); ?></div>
                <div class="sub-value">Total quantity</div>
            </div>
            <div class="summary-card">
                <div class="label">Average Sale</div>
                <div class="value"><?php echo formatPeso($avg_sale); ?></div>
                <div class="sub-value">Per transaction</div>
            </div>
        </div>

        <!-- Cash Summary - Simplified (GCash removed) -->
        <div class="cash-summary">
            <div class="cash-icon">💵</div>
            <div class="cash-details">
                <div class="title">Cash Transactions</div>
                <div class="cash-stats">
                    <div class="stat-item">
                        <span class="stat-label">Total Cash</span>
                        <span class="stat-number"><?php echo formatPeso($total_revenue); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Transactions</span>
                        <span class="stat-number"><?php echo number_format($total_transactions); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Items Sold</span>
                        <span class="stat-number"><?php echo number_format($total_items_sold); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Sales Table -->
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Date & Time</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Total Amount</th>
                        <th>Payment</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sales)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 3rem;">
                            <div class="empty-state">
                                <i>🛒</i>
                                <h3>No Sales Records</h3>
                                <p>Start by creating your first sale.</p>
                                <a href="new_sale.php" class="btn btn-primary">New Sale</a>
                            </div>
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($sales as $sale): ?>
                        <tr>
                            <td>
                                <span class="invoice-number">#<?php echo htmlspecialchars($sale['invoice_number']); ?></span>
                            </td>
                            <td>
                                <?php echo date('M d, Y', strtotime($sale['sale_date'])); ?>
                                <br>
                                <small style="color: #64748b;"><?php echo date('h:i A', strtotime($sale['sale_date'])); ?></small>
                            </td>
                            <td>
                                <span class="customer-name">
                                    <?php echo formatCustomerName($sale['customer_name']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="item-count">
                                    <?php echo $sale['item_count']; ?> item<?php echo $sale['item_count'] != 1 ? 's' : ''; ?>
                                </span>
                            </td>
                            <td>
                                <span class="price">
                                    <?php echo formatPeso($sale['total_amount']); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo getPaymentMethodBadge($sale['payment_method']); ?>
                            </td>
                            <td>
                                <a href="invoice.php?id=<?php echo $sale['id']; ?>" class="btn-view">
                                    View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Optional: Database cleanup message -->
        <?php if (!empty($sales)): 
            // Check if there are any non-cash payments
            $check_gcash = $pdo->query("SELECT COUNT(*) FROM sales WHERE LOWER(payment_method) != 'cash'")->fetchColumn();
            if ($check_gcash > 0): 
        ?>
        <div style="margin-top: 1rem; padding: 1rem; background: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
            <strong>📝 Note:</strong> There are <?php echo $check_gcash; ?> transactions with non-cash payment methods in the database. 
            They are displayed as Cash in this view. Run this SQL to update them: 
            <code style="display: block; margin-top: 0.5rem; padding: 0.5rem; background: #fff; border-radius: 4px;">
                UPDATE sales SET payment_method = 'Cash' WHERE payment_method != 'Cash';
            </code>
        </div>
        <?php 
            endif;
        endif; 
        ?>
    </div>
</body>
</html>