<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // For demo purposes - in production, use password_hash() and verify
    if ($username == 'admin' && $password == 'admin123') {
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = 'admin';
        $_SESSION['full_name'] = 'Administrator';
        $_SESSION['role'] = 'admin';
        header('Location: index.php');
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>City Tourism Inventory - Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-header">
            <div class="logo-container" style="justify-content: center; margin-bottom: 1rem;">
                <img src="logo.png" alt="Malaybalay City Tourism" style="height: 60px; border-radius: 10px;" onerror="this.src='logo.jpg'; this.onerror=null;">
            </div>
            <h1>City Tourism Malaybalay</h1>
            <p>Welcome • Mabuhay </p>
            <p style="font-size: 0.9rem; margin-top: 0.5rem;">Inventory Management System</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="" class="login-form">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">Login</button>
        </form>
        
        <div class="login-footer">
            <p>admin / admin123</p>
        </div>
    </div>
</body>
</html>