<?php
require_once 'config.php';
requireLogin();

if (!isset($_GET['id'])) {
    header('Location: sales.php');
    exit();
}

$sale_id = $_GET['id'];

// Get sale details
$stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ?");
$stmt->execute([$sale_id]);
$sale = $stmt->fetch();

if (!$sale) {
    header('Location: sales.php');
    exit();
}

// Get sale items
$stmt = $pdo->prepare("
    SELECT si.*, i.item_name, i.category 
    FROM sale_items si 
    JOIN items i ON si.item_id = i.id 
    WHERE si.sale_id = ?
");
$stmt->execute([$sale_id]);
$items = $stmt->fetchAll();

// Function to convert number to words (Philippine Peso format)
function numberToWords($num) {
    $num = (float)$num;
    $pesos = floor($num);
    $centavos = round(($num - $pesos) * 100);
    
    $words = convertNumberToWords($pesos);
    
    if ($centavos > 0) {
        $words .= ' Pesos and ' . convertNumberToWords($centavos) . ' Centavos';
    } else {
        $words .= ' Pesos Only';
    }
    
    return $words;
}

function convertNumberToWords($number) {
    $number = (int)$number;
    
    if ($number == 0) return 'Zero';
    
    $words = array(
        0 => '',
        1 => 'One',
        2 => 'Two',
        3 => 'Three',
        4 => 'Four',
        5 => 'Five',
        6 => 'Six',
        7 => 'Seven',
        8 => 'Eight',
        9 => 'Nine',
        10 => 'Ten',
        11 => 'Eleven',
        12 => 'Twelve',
        13 => 'Thirteen',
        14 => 'Fourteen',
        15 => 'Fifteen',
        16 => 'Sixteen',
        17 => 'Seventeen',
        18 => 'Eighteen',
        19 => 'Nineteen',
        20 => 'Twenty',
        30 => 'Thirty',
        40 => 'Forty',
        50 => 'Fifty',
        60 => 'Sixty',
        70 => 'Seventy',
        80 => 'Eighty',
        90 => 'Ninety'
    );
    
    $levels = array(
        1000000000 => 'Billion',
        1000000 => 'Million',
        1000 => 'Thousand',
        100 => 'Hundred'
    );
    
    if ($number < 20) {
        return $words[$number];
    }
    
    if ($number < 100) {
        $tens = floor($number / 10) * 10;
        $ones = $number % 10;
        if ($ones == 0) {
            return $words[$tens];
        } else {
            return $words[$tens] . ' ' . $words[$ones];
        }
    }
    
    foreach ($levels as $divisor => $levelName) {
        if ($number >= $divisor) {
            $count = floor($number / $divisor);
            $remainder = $number % $divisor;
            
            $result = convertNumberToWords($count) . ' ' . $levelName;
            
            if ($remainder > 0) {
                $result .= ' ' . convertNumberToWords($remainder);
            }
            
            return $result;
        }
    }
    
    return 'Number too large';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - Malaybalay City Tourism Inventory</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .invoice {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            box-shadow: var(--shadow-hover);
            max-width: 900px;
            margin: 2rem auto;
            border: 2px solid var(--tribal-primary);
            position: relative;
        }
        
        .invoice::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: repeating-linear-gradient(90deg, 
                var(--tribal-terracotta) 0px, 
                var(--tribal-terracotta) 15px,
                var(--tribal-gold) 15px,
                var(--tribal-gold) 30px);
            border-radius: 20px 20px 0 0;
        }
        
        .invoice-header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 2px dashed var(--tribal-secondary);
        }
        
        .invoice-header h1 {
            color: var(--tribal-primary);
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .invoice-header h2 {
            color: var(--tribal-gold);
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .invoice-details {
            margin-bottom: 2rem;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 15px;
            border: 1px solid var(--tribal-secondary);
        }
        
        .detail-box {
            padding: 0.5rem;
        }
        
        .detail-box p {
            margin-bottom: 0.5rem;
        }
        
        .detail-box strong {
            color: var(--tribal-primary);
            min-width: 100px;
            display: inline-block;
        }
        
        .total-row {
            font-size: 1.2rem;
            font-weight: bold;
            background: linear-gradient(135deg, #8B451320, #B2222220);
        }
        
        .total-row td {
            padding: 1rem !important;
        }
        
        .amount-in-words {
            margin-top: 2rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 10px;
            font-style: italic;
            border-left: 4px solid var(--tribal-gold);
            font-size: 1.1rem;
        }
        
        .print-btn {
            text-align: center;
            margin-top: 2rem;
        }
        
        @media print {
            .navbar, .print-btn, .no-print {
                display: none !important;
            }
            .invoice {
                box-shadow: none;
                padding: 1rem;
                border: 1px solid #ccc;
            }
        }
        
        .category-badge {
            background: var(--tribal-primary);
            color: white;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .payment-badge {
            background: #00b09b;
            color: white;
            padding: 0.3rem 1rem;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 500;
            display: inline-block;
        }
        
        .watermark {
            position: absolute;
            bottom: 20px;
            right: 20px;
            opacity: 0.1;
            font-size: 8rem;
            transform: rotate(-15deg);
            pointer-events: none;
            color: var(--tribal-primary);
        }
        
        .signature-area {
            margin-top: 3rem;
            display: flex;
            justify-content: space-between;
            padding: 0 2rem;
        }
        
        .signature-line {
            text-align: center;
        }
        
        .signature-line .line {
            width: 200px;
            border-top: 1px solid var(--tribal-secondary);
            margin-top: 2rem;
            padding-top: 0.5rem;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo-container">
            <img src="logo.png" alt="Malaybalay City Tourism" class="logo" onerror="this.src='logo.jpg'; this.onerror=null;">
            <div class="brand-text">
                <span class="brand-main">MALAYBALAY</span>
                <span class="brand-sub">coolplace • warmpeople</span>
            </div>
        </div>
        <div class="nav-menu">
            <a href="index.php">Dashboard</a>
            <a href="items.php">Items</a>
            <a href="sales.php">Sales</a>
            <a href="new_sale.php">New Sale</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="invoice">
            <div class="watermark">🇵🇭</div>
            
            <div class="invoice-header">
                <img src="logo.png" alt="Malaybalay City Tourism" style="height: 80px; margin-bottom: 1rem;" onerror="this.style.display='none'">
                <h1>Malaybalay City Tourism</h1>
                <h2>Official Sales Invoice</h2>
                <p><strong>coolplace • warmpeople • since 2026</strong></p>
            </div>
            
            <div class="invoice-details">
                <div class="detail-box">
                    <p><strong>Invoice #:</strong> <?php echo htmlspecialchars($sale['invoice_number']); ?></p>
                    <p><strong>Date:</strong> <?php echo date('F d, Y', strtotime($sale['sale_date'])); ?></p>
                    <p><strong>Time:</strong> <?php echo date('h:i A', strtotime($sale['sale_date'])); ?></p>
                </div>
                <div class="detail-box">
                    <p><strong>Customer:</strong> 
                        <?php 
                        if (strpos($sale['customer_name'], 'Foreign Tourist') !== false) {
                            echo '🌏 ' . htmlspecialchars($sale['customer_name']);
                        } else {
                            echo '🇵🇭 ' . htmlspecialchars($sale['customer_name']);
                        }
                        ?>
                    </p>
                    <p><strong>Payment Method:</strong> 
                        <span class="payment-badge">💵 Cash</span>
                    </p>
                    <p><strong>Cashier:</strong> <?php echo $_SESSION['full_name'] ?? 'Staff'; ?></p>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Category</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total = 0;
                    foreach ($items as $item): 
                        $total += $item['subtotal'];
                    ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($item['item_name']); ?></strong></td>
                        <td><span class="category-badge"><?php echo htmlspecialchars($item['category'] ?: 'Uncategorized'); ?></span></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td><?php echo formatPeso($item['unit_price']); ?></td>
                        <td><?php echo formatPeso($item['subtotal']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="total-row">
                        <td colspan="4" style="text-align: right;"><strong>Total Amount:</strong></td>
                        <td><strong><?php echo formatPeso($total); ?></strong></td>
                    </tr>
                </tfoot>
            </table>
            
            <div class="amount-in-words">
                <strong>Amount in Words:</strong> 
                <?php echo numberToWords($total); ?>
            </div>
            
            <div class="signature-area">
                <div class="signature-line">
                    <div class="line">Customer Signature</div>
                </div>
                <div class="signature-line">
                    <div class="line">Cashier Signature</div>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 2rem;">
                <p style="color: var(--tribal-primary);">Thank you for supporting Malaybalay City Tourism!</p>
                <p style="font-size: 0.9rem; color: var(--gray-color);">This invoice serves as official receipt</p>
            </div>
            
            <div class="print-btn no-print">
                <button onclick="window.print()" class="btn btn-primary" style="margin-right: 1rem;">🖨️ Print Invoice</button>
                <a href="sales.php" class="btn btn-info">← Back to Sales</a>
            </div>
        </div>
    </div>
</body>
</html>